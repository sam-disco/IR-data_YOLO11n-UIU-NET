"""UIU-Net — 공개 원 저장소 받기(고정 커밋 · 파일 sha256) · 모형 불러오기(원 파일은 고치지 않음) · 학습 루프 · 추론.
기존 저장소 IR-night-filter(14차 수정4) src/irfilter/u_net.py에서 옮겼다. model_class의 안내 문장만 고쳤고 나머지는 그대로다(대응표 docs/FILE_MAP.md).
원 코드(github.com/danfenghong/IEEE_TIP_UIU-Net)는 이 패키지에 넣지 않는다: 처음 실행할 때 uiunet/third_party/에 받는다(.gitignore).
라이선스 표기는 원 저장소의 README(GPL-3.0)와 LICENSE 파일(Apache-2.0)에서 다르다.
값은 원 코드 기본값: 손실 = 7개 출력(d0 결합 + 옆 출력 6) 각각 BCE(평균)의 합, 가중 1 · Adam lr 1e-3 · betas (0.9, 0.999) · eps 1e-8 · wd 0 ·
스케줄 없음 · 최종 출력 = σ(d0)."""
import io, os, sys, time, zipfile
import numpy as np
from common import Stop, now, sha_file, wjson, rjson, ROOT
from . import u_data as UD


# ================================================================ 원 저장소 (고정 커밋) — fetch · _dir · build_model은 기존 그대로
def fetch(cfg, out=print):
    """codeload zip(커밋 고정)에서 쓰는 파일만 꺼내 third_party/uiunet/에 둔다 · 파일마다 sha256 = configs u.files. 이미 있으면 해시만 본다."""
    U = cfg['u']; d = _dir(cfg); ok = True
    have = all(os.path.exists(os.path.join(d, f)) and sha_file(os.path.join(d, f)) == h for f, h in U['files'].items())
    if not have:
        import urllib.request
        url = U['zip_url'].format(commit=U['commit']); out('UIU-Net 원 저장소 받기', url)
        req = urllib.request.Request(url, headers={'User-Agent': 'IR-night-filter'})
        with urllib.request.urlopen(req, timeout=120) as r:
            b = r.read()
        z = zipfile.ZipFile(io.BytesIO(b)); pre = z.namelist()[0]
        if U['commit'] not in pre:
            raise Stop(f'zip 머리 폴더 {pre}에 커밋 {U["commit"][:8]}가 없다')
        for f in U['files']:
            data = z.read(pre + f); p = os.path.join(d, f); os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, 'wb').write(data)
    rep = {}
    for f, h in U['files'].items():
        g = sha_file(os.path.join(d, f)); rep[f] = g; ok &= g == h
        if g != h:
            out(f'  {f}: sha256 {g[:8]}… ≠ 고정 {h[:8]}…')
    if not ok:
        raise Stop('UIU-Net 원 파일 sha256이 고정 값과 다르다 — 멈춤(PREREG_U 8-1)')
    out(f'UIU-Net 원 파일 {len(rep)}개 sha256 모두 고정 값과 같음(커밋 {U["commit"][:8]})')
    return dict(commit=U['commit'], files=rep, dir=d)


def _dir(cfg):
    d = cfg['u']['dir']
    return d if os.path.isabs(d) else os.path.join(ROOT, d)


def model_class(cfg):
    """원 model 패키지(model/__init__.py · uiunet.py · fusion.py)를 그대로 불러 UIUNET 클래스를 돌려준다(원 파일은 고치지 않음).
    기존 u_net.model_class. 고친 곳: 해시가 다를 때의 안내 문장(이 패키지의 명령으로)."""
    d = _dir(cfg)
    for f, h in cfg['u']['files'].items():
        if f.startswith('model/') and sha_file(os.path.join(d, f)) != h:
            raise Stop(f'{f} sha256이 고정 값과 다르다 — {d} 폴더를 지우고 같은 명령을 다시 실행한다(다시 받는다)')
    import importlib
    if d not in sys.path:
        sys.path.insert(0, d)
    m = importlib.import_module('model')
    if os.path.dirname(os.path.abspath(m.__file__)) != os.path.join(os.path.abspath(d), 'model'):
        raise Stop(f'다른 「model」 패키지가 먼저 잡혔다: {m.__file__}')
    return m.UIUNET


def build_model(cfg, seed):
    import torch
    torch.manual_seed(seed)
    return model_class(cfg)(3, 1)


# ================================================================ 학습 설정 · 손실 (기존 그대로)
def set_det(seed, deterministic=True, benchmark=False):
    """seed 고정 + 결정성 설정. 기본값(deterministic True · benchmark False)은 10차까지와 같은 동작.
    deterministic False → cudnn.deterministic False · use_deterministic_algorithms(False) · benchmark True → cudnn.benchmark True (11차 u2.train.speed)"""
    import random, torch
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = bool(deterministic); torch.backends.cudnn.benchmark = bool(benchmark)
    torch.use_deterministic_algorithms(bool(deterministic), warn_only=True)   # 쌍선형 업샘플 역전파는 GPU에서 결정적이 아니다 — 경고만(한계)


def loss_fn(outs, y, w):
    """원 train.py muti_bce_loss_fusion: 7개 출력 BCE 합(가중 1). 무게 w(DontCare 0)는 원소별 곱 — 평균은 전체 원소 수로 나눔(원 BCELoss(size_average=True)와 무게 1일 때 같음)"""
    import torch.nn.functional as F
    ls = [F.binary_cross_entropy(o, y, weight=w, reduction='mean') for o in outs]
    return ls[0], sum(ls)


# ================================================================ 추론 (기존 그대로)
def load_net(cfg, path, dev):
    import torch
    net = model_class(cfg)(3, 1); net.load_state_dict(torch.load(path, map_location=dev, weights_only=True)); return net.to(dev).eval()


def prob_maps(net, img, dev, modes=('F', 'T'), tile_batch=3):
    """U2 추론(3절): uint8 (512, 640, 3) → {'F': 영상 전체 한 번, 'T': 320 조각 9개 · 겹친 곳 최댓값}. 정규화는 고정 상수(4절)라
    영상을 한 번 정규화한 뒤 잘라도 조각마다 정규화한 것과 같다(합성 시험 13-1 · 13-2). 추론은 FP32(AMP는 학습에만)."""
    import torch
    out = {}
    x = UD.normalize_fixed(img)                                  # (3, h, w)
    h, w = img.shape[:2]
    with torch.no_grad():
        if 'F' in modes:
            xp, _, _ = UD.pad_to(img, 32)                         # 덧댐은 정규화 전 화소 0(4절) — 640×512는 덧대지 않음
            xf = x if xp.shape[:2] == (h, w) else UD.normalize_fixed(xp)
            out['F'] = net(torch.from_numpy(xf)[None].to(dev))[0][0, 0, :h, :w].float().cpu().numpy()
        if 'T' in modes:
            xy = UD.tiles_xy(h, w); parts = []
            for k in range(0, len(xy), tile_batch):
                ch = xy[k:k + tile_batch]
                xb = torch.from_numpy(np.stack([x[:, y0:y0 + UD.TILE, x0:x0 + UD.TILE] for y0, x0 in ch]))
                pb = net(xb.to(dev))[0][:, 0].float().cpu().numpy()
                parts += [(y0, x0, pb[j]) for j, (y0, x0) in enumerate(ch)]
            out['T'] = UD.stitch_max(parts, h, w)
    return out


# ================================================================ 학습 루프 (기존 그대로 — 이 패키지는 손실 A · FP32 · 속도 설정 C만 쓴다)
def soft_iou(p, g, w, eps=1e-6):
    """손실 B의 보조 항(PREREG_U2 5절): 1 − Σ(p·g) ÷ (Σp + Σg − Σ(p·g)), DontCare 화소(무게 0) 제외 · 묶음 전체로 합. eps는 0 ÷ 0 막음(분자 · 분모에 같게)"""
    m = (w > 0).to(p.dtype); i = (p * g * m).sum(); u = (p * m).sum() + (g * m).sum() - i
    return 1 - (i + eps) / (u + eps)


def loss_u2(outs, y, w, kind='A'):
    """U2 손실(5절). 출력은 float32로 바꿔 autocast 밖에서 계산(가-코드-2 — BCELoss는 autocast 안에서 못 씀).
    A = 원 코드(7개 BCE 합, 무게 1 · DontCare 0 · 전체 원소 평균) · B = A + Soft-IoU(d0). 반환 (d0 BCE, 전체)"""
    o32 = [o.float() for o in outs]
    l0, l = loss_fn(o32, y.float(), w.float())
    if kind == 'B':
        l = l + soft_iou(o32[0], y.float(), w.float())
    elif kind != 'A':
        raise ValueError(f'손실 {kind}')
    return l0, l


class NonFinite(Exception):
    """손실이 NaN/Inf — 멈춤(PREREG_U2 9절)"""


def amp_mode(dev, want):
    """want: 'fp32' · 'amp'. amp는 bf16(지원하면) — 아니면 fp16 + GradScaler(7절). 반환 (이름, autocast dtype 또는 None, GradScaler 쓰나)"""
    import torch
    if want == 'fp32' or dev.type != 'cuda':
        return ('fp32', None, False) if want == 'fp32' else ('bf16(cpu)', torch.bfloat16, False)
    if torch.cuda.is_bf16_supported():
        return 'bf16', torch.bfloat16, False
    return 'fp16', torch.float16, True


SPEED_DEFAULT = dict(deterministic=True, benchmark=False, nan_check='iter')   # = 10차 동작(11차 u2.train.speed 기본값)


def speed_of(T):
    """configs u2.train.speed → {deterministic, benchmark, nan_check}. 칸이 없으면(10차 설정 · 10차 ckpt) 10차 동작 값"""
    s = dict(SPEED_DEFAULT, **((T or {}).get('speed') or {}))
    if set(s) != set(SPEED_DEFAULT) or s['nan_check'] not in ('iter', 'epoch') or not all(isinstance(s[k], bool) for k in ('deterministic', 'benchmark')):
        raise ValueError(f'u2.train.speed {s} — deterministic · benchmark는 true/false, nan_check는 iter · epoch')
    return s


class StepAcc:
    """한 epoch의 손실 합 · 유한성. nan_check 'iter' = 10차 그대로(반복마다 bool() · float()로 GPU 대기) ·
    'epoch' = 손실은 GPU 텐서로 더하고(detach) 유한성은 GPU 불리언 하나에 누적 → epoch 끝 close()에서 한 번만 CPU로"""

    def __init__(self, nan_check, dev):
        import torch
        self.mode = nan_check; self.k = 0
        if nan_check == 'iter':
            self.s0 = self.s_all = 0.0
        else:
            self.s0 = torch.zeros((), dtype=torch.float64, device=dev); self.s_all = torch.zeros((), dtype=torch.float64, device=dev)
            self.bad = torch.zeros((), dtype=torch.bool, device=dev)

    def close(self):
        """epoch 끝: (d0 손실 합, 전체 손실 합, 유한성 깨짐 여부) — epoch 모드는 여기서 처음 GPU를 기다린다"""
        if self.mode == 'iter':
            return self.s0, self.s_all, False
        return float(self.s0), float(self.s_all), bool(self.bad)


def train_step(net, opt, x, y, w, adt, scaler, use_scaler, loss, acc, where):
    """U2 학습 한 반복(train_run2 · bench가 같이 씀). nan_check 'iter'의 계산 순서는 10차 train_run2 반복 본문과 같다."""
    import torch
    opt.zero_grad(set_to_none=True)
    if adt is not None:
        with torch.autocast(device_type=x.device.type, dtype=adt):
            outs = net(x)
    else:
        outs = net(x)
    if acc.mode == 'iter':
        if not all(bool(torch.isfinite(o).all()) for o in outs):
            raise NonFinite(f'{where}: 출력에 NaN/Inf')
    else:
        for o in outs:
            acc.bad |= ~torch.isfinite(o).all()
        # 손실에는 NaN을 0.5로 바꾼 값을 넘긴다: binary_cross_entropy는 [0, 1] 밖(NaN 포함)이면 CPU는 오류, CUDA는 장치 단언(device-side assert)으로
        # 프로세스가 깨진다 — epoch 끝 검사까지 가려면 필요. 유한한 값은 그대로(값 · 기울기 같음). 깨짐 여부는 위에서 원래 출력으로 기록했다
        outs = [torch.nan_to_num(o, nan=0.5, posinf=1.0, neginf=0.0) for o in outs]
    l0, l = loss_u2(outs, y, w, loss)                       # autocast 밖 · float32
    if acc.mode == 'iter':
        if not torch.isfinite(l):
            raise NonFinite(f'{where}: 손실 {float(l)}')
    else:
        acc.bad |= ~torch.isfinite(l)
    if scaler is not None and use_scaler:
        scaler.scale(l).backward(); scaler.step(opt); scaler.update()
    else:
        l.backward(); opt.step()
    if acc.mode == 'iter':
        acc.s0 += float(l0); acc.s_all += float(l)
    else:
        acc.s0 += l0.detach().double(); acc.s_all += l.detach().double()
    acc.k += 1


def train_run2(cfg, T, rows, build, run_dir, seed, epochs, mode='fp32', loss='A', batch=4, eval_every=0, eval_fn=None,
               keep_epochs=(), out=print, max_iters=None, stopper=None):
    """U2 학습 한 번 → run_dir/last.pth · run_record.json. 끊기면 epoch 단위로 이어 간다(run_dir/ckpt.pth · GradScaler 상태 포함).
    T = cfg['u2']['train'](crop · lr · betas · eps · weight_decay · workers · flip · mask · dontcare · mask_scale · tile_batch · speed).
    eval_every > 0이면 그 epoch마다 eval_fn(net, epoch) → dict를 기록(K3 칸만 · 결정에 쓰지 않음). keep_epochs의 epoch에는 w_e<epoch>.pth를 남긴다.
    stopper(epoch) → 문자열이면 그 epoch 뒤 멈춤(GPU 상한 등). 손실이 NaN/Inf면 NonFinite.
    T['speed'](11차, 없으면 10차 동작): deterministic · benchmark → set_det · nan_check 'epoch'면 유한성을 epoch 끝에 한 번 보고, 깨졌으면
    그 epoch의 ckpt를 쓰기 전에 NonFinite(마지막 ckpt는 앞의 정상 epoch 것으로 남음)."""
    import torch
    os.makedirs(run_dir, exist_ok=True)
    dev = torch.device(f"cuda:{cfg['device']}" if str(cfg['device']) != 'cpu' and torch.cuda.is_available() else 'cpu')
    spd = speed_of(T)
    set_det(seed, spd['deterministic'], spd['benchmark'])
    ds = UD.U2Dataset(build, rows, T['crop'], T['mask'], seed, T['flip'], T['dontcare'], T['mask_scale'], 'fixed', out)
    net = build_model(cfg, seed).to(dev)
    opt = torch.optim.Adam(net.parameters(), lr=T['lr'], betas=tuple(T['betas']), eps=T['eps'], weight_decay=T['weight_decay'])
    mname, adt, use_scaler = amp_mode(dev, mode)
    scaler = torch.amp.GradScaler('cuda', enabled=use_scaler) if dev.type == 'cuda' else None
    ck = os.path.join(run_dir, 'ckpt.pth'); start = 0; log = []
    rec = dict(seed=seed, n_train=len(rows), batch=batch, epochs=epochs, precision=mname, loss=loss, norm='fixed', train_cfg=T, device=str(dev),
               started=now(), list_sha256=cfg.get('_u_list_sha'), commit=cfg['u']['commit'], png_bytes=ds.bytes, speed=spd)
    if os.path.exists(ck):
        s = torch.load(ck, map_location=dev, weights_only=False)
        net.load_state_dict(s['net']); opt.load_state_dict(s['opt']); start = s['epoch']; log = s['log']; rec = s['rec']
        if scaler is not None and s.get('scaler'):
            scaler.load_state_dict(s['scaler'])
        torch.set_rng_state(s['rng_cpu'])
        old_spd = speed_of(dict(speed=rec.get('speed')))          # 10차 ckpt에는 speed가 없다 → 10차 동작 값
        if (rec['precision'], rec['loss'], rec['batch'], old_spd) != (mname, loss, batch, spd):
            raise RuntimeError(f"이어 갈 ckpt의 방식 {rec['precision']} · {rec['loss']} · 배치 {rec['batch']} · speed {old_spd} ≠ 지금 {mname} · {loss} · {batch} · speed {spd}")
        rec['speed'] = spd
        out(f'  이어 감: epoch {start}부터')
    if dev.type == 'cuda':
        torch.cuda.reset_peak_memory_stats()
    smp = UD.EpochSampler(len(ds), seed)
    nw = int(T['workers'])
    dl = torch.utils.data.DataLoader(ds, batch_size=batch, sampler=smp, drop_last=True, num_workers=nw, persistent_workers=nw > 0,
                                     pin_memory=dev.type == 'cuda')
    it_per_epoch = len(ds) // batch                              # drop_last(원 train.py 98줄)
    t_all = time.time(); n_it = start * it_per_epoch; stop_msg = None
    for ep in range(start, epochs):
        smp.set_epoch(ep); net.train(); t0 = time.time(); wait = 0.0; acc = StepAcc(spd['nan_check'], dev)
        it = iter(dl)
        while True:
            ta = time.perf_counter()
            try:
                x, y, w = next(it)
            except StopIteration:
                break
            wait += time.perf_counter() - ta
            x, y, w = x.to(dev, non_blocking=True), y.to(dev, non_blocking=True), w.to(dev, non_blocking=True)
            train_step(net, opt, x, y, w, adt, scaler, use_scaler, loss, acc, f'epoch {ep + 1} 반복 {acc.k + 1}')
            n_it += 1
            if max_iters and n_it >= max_iters:
                break
        s0, s_all, bad = acc.close(); k = acc.k                   # epoch 모드는 여기서 한 번 GPU를 기다린다
        if bad:                                                  # ckpt · w_e · 평가보다 앞 — 마지막 ckpt는 앞의 정상 epoch 것
            raise NonFinite(f'epoch {ep + 1}: 출력 또는 손실에 NaN/Inf (epoch 끝 검사, 반복 {k}개 중) — 이 epoch의 ckpt는 쓰지 않음')
        sec = time.time() - t0
        e = dict(epoch=ep + 1, iters=k, loss=s_all / max(k, 1), loss0=s0 / max(k, 1), seconds=sec, data_wait_s=wait, data_wait_ratio=wait / max(sec, 1e-9),
                 max_mem_GB=(torch.cuda.max_memory_allocated() / 1e9) if dev.type == 'cuda' else None)
        if eval_fn and eval_every and (ep + 1) % eval_every == 0:
            te = time.time(); net.eval(); e.update(eval_fn(net, ep + 1)); net.train(); e['eval_seconds'] = time.time() - te
        log.append(e)
        out(f"  epoch {ep + 1}/{epochs} · 반복 {k} · 손실 {e['loss']:.4f} (d0 {e['loss0']:.4f}) · {sec:.0f} s · 대기 {100 * e['data_wait_ratio']:.1f}%" +
            (f" · 최대 메모리 {e['max_mem_GB']:.2f} GB" if e['max_mem_GB'] else '') + (f" · {e['note']}" if e.get('note') else ''))
        if (ep + 1) in keep_epochs:
            wp = os.path.join(run_dir, f'w_e{ep + 1}.pth'); torch.save(net.state_dict(), wp + '.tmp'); os.replace(wp + '.tmp', wp)
        torch.save(dict(net=net.state_dict(), opt=opt.state_dict(), epoch=ep + 1, log=log, rec=rec, rng_cpu=torch.get_rng_state(),
                        scaler=scaler.state_dict() if (scaler is not None and use_scaler) else None), ck + '.tmp')
        os.replace(ck + '.tmp', ck)
        if max_iters and n_it >= max_iters:
            break
        if stopper:
            stop_msg = stopper(ep + 1)
            if stop_msg and ep + 1 < epochs:
                rec['stopped'] = stop_msg; return rec
    lp = os.path.join(run_dir, 'last.pth'); torch.save(net.state_dict(), lp + '.tmp'); os.replace(lp + '.tmp', lp)
    rec.update(finished=now(), wall_time_s_this_session=time.time() - t_all, iterations=n_it, it_per_epoch=it_per_epoch, epoch_log=log,
               last_sha256=sha_file(lp), train_seconds=sum(x['seconds'] for x in log), eval_seconds=sum(x.get('eval_seconds', 0) for x in log),
               max_mem_GB=max([x['max_mem_GB'] or 0 for x in log] or [0]))
    wjson(os.path.join(run_dir, 'run_record.json'), rec)
    if os.path.exists(ck):
        os.replace(ck, ck + '.done')
    return rec


def run_state(run_dir):
    """'done'(run_record 해시 = last.pth) · 'todo'(폴더 없음) · 'resume'(ckpt.pth 있음) · 'partial'(그 밖 — 멈춤)"""
    if not os.path.exists(run_dir):
        return 'todo'
    rr, lp = os.path.join(run_dir, 'run_record.json'), os.path.join(run_dir, 'last.pth')
    if os.path.exists(rr) and os.path.exists(lp) and rjson(rr).get('last_sha256') == sha_file(lp):
        return 'done'
    if os.path.exists(os.path.join(run_dir, 'ckpt.pth')):
        return 'resume'
    return 'partial'
