"""UIU-Net 데이터 쪽 — 상자 → 학습 마스크 · 한 목록 CSV 로더 · 학습 조각(잘라 냄 · 좌우 뒤집기) · 입력 정규화 · 출력 → 상자.
기존 저장소 IR-night-filter(14차 수정4) src/irfilter/u_data.py에서 옮겼다. NORMS · list_rows만 고쳤고 나머지는 그대로다(대응표 docs/FILE_MAP.md).

UIU-Net은 화소마다 「사람인가」를 내는 분할 모형이라 정답이 상자가 아니라 마스크여야 한다. HIT-UAV에는 상자만 있으므로
사람 상자에 내접한 타원을 0.5배로 줄여 정답 마스크로 쓴다(draw_mask). DontCare 상자 안은 손실에서 뺀다(weight_map — 무게 0).
마스크는 파일로 저장하지 않고 학습 중에 라벨에서 그린다.

좌표 약속: HIT-UAV 상자는 정수 (x, y, w, h) — 화소 x…x+w−1 · 연속 좌표 [x, x+w). 라벨 파일은 YOLO txt.
마스크 화소 규칙: 열 i는 화소 중심 i + 0.5가 [x0, x1) 안일 때 넣는다(정수 상자면 정확히 x0 … x1−1). 한 칸도 없으면 가운데 한 칸."""
import functools, io, json, math, os
import numpy as np
from common import Stop, sha_file, sha_bytes, rcsv, hash_ok

MEAN = (0.485, 0.456, 0.406)          # 원 코드 data_loader.py ToTensorLab(flag=0) 206~212줄 — 3채널 영상은 채널마다 이 값


STD = (0.229, 0.224, 0.225)


LIST_COLS = ['stem', 'source', 'image', 'image_sha256', 'label', 'label_sha256', 'ignore']


# ================================================================ 상자 → 마스크 (기존 그대로)
def _span(a0, a1, n):
    """연속 구간 [a0, a1) → 화소 번호 [i0, i1) (중심 규칙) · 영상 밖은 자름 · 빈 구간이면 가운데 한 칸"""
    i0, i1 = math.ceil(a0 - 0.5), math.ceil(a1 - 0.5)
    if i1 <= i0:
        i0 = int(math.floor((a0 + a1) / 2)); i1 = i0 + 1
    return max(i0, 0), min(i1, n)


def draw_mask(boxes, h, w, shape='box', s=1.0):
    """boxes [(x0, y0, x1, y1)] 연속 좌표 → uint8 (h, w) {0, 1}. shape: box(채운 상자) · ellipse(상자에 내접한 타원 — 화소 중심이 타원 안).
    s = 마스크 배율(PREREG_U v1.1 A11): 상자 중심을 그대로 두고 반지름(또는 반변)을 s배. 사람마다 그려지는 화소가 0이면 중심 화소 하나(A11-1)."""
    m = np.zeros((h, w), np.uint8)
    for x0, y0, x1, y1 in boxes:
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; a, b = s * (x1 - x0) / 2, s * (y1 - y0) / 2
        c0, c1 = _span(cx - a, cx + a, w); r0, r1 = _span(cy - b, cy + b, h); got = False
        if c1 > c0 and r1 > r0:
            if shape == 'box':
                m[r0:r1, c0:c1] = 1; got = True
            else:
                yy, xx = np.mgrid[r0:r1, c0:c1]
                inside = ((xx + 0.5 - cx) / max(a, 1e-9)) ** 2 + ((yy + 0.5 - cy) / max(b, 1e-9)) ** 2 <= 1.0
                m[r0:r1, c0:c1] |= inside.astype(np.uint8); got = bool(inside.any())
        if not got:
            m[min(max(int(math.floor(cy)), 0), h - 1), min(max(int(math.floor(cx)), 0), w - 1)] = 1
    return m


def weight_map(person_mask, ignore_boxes, h, w):
    """DontCare 손실 무게: DontCare 상자 화소 중 사람 마스크가 아닌 곳 = 0, 그 밖 = 1 (PREREG_U 2-1)"""
    wm = np.ones((h, w), np.float32)
    if ignore_boxes:
        ig = draw_mask(ignore_boxes, h, w, 'box').astype(bool) & (person_mask == 0)
        wm[ig] = 0.0
    return wm


def person_boxes_txt(txt, w, h):
    """YOLO txt(클래스 0 = Person만) → 연속 좌표 상자. Car · Bicycle · OtherVehicle은 버린다(마스크 0)."""
    out = []
    for l in txt.splitlines():
        p = l.split()
        if not p or int(p[0]) != 0:
            continue
        cx, cy, bw, bh = (float(v) for v in p[1:5])
        out.append(((cx - bw / 2) * w, (cy - bh / 2) * h, (cx + bw / 2) * w, (cy + bh / 2) * h))
    return out


def hit_boxes(boxes, cls=0):
    """HIT-UAV 정수 상자 [(cls, x, y, w, h)] → 연속 좌표 (x, y, x+w, y+h), 영상 안으로 자름"""
    return [(max(x, 0), max(y, 0), min(x + bw, 640), min(y + bh, 512)) for c, x, y, bw, bh in boxes if c == cls]


# ================================================================ 출력 → 상자 (기존 그대로)
@functools.lru_cache(maxsize=None)
def _extent(w, h, px, py, s):
    """정수 크기 (w, h) 상자(중심 소수부 px, py ∈ {0, 0.5})를 배율 s 타원(화소 중심 규칙, 빈 사람은 한 칸)으로 그렸을 때 외접 (가로, 세로)"""
    a, b = s * w / 2, s * h / 2
    xs = np.arange(-math.ceil(a) - 2, math.ceil(a) + 3) + 0.5 - px
    ys = np.arange(-math.ceil(b) - 2, math.ceil(b) + 3) + 0.5 - py
    m = (xs[None, :] / a) ** 2 + (ys[:, None] / b) ** 2 <= 1
    if not m.any():
        return 1, 1
    c = np.nonzero(m.any(0))[0]; r = np.nonzero(m.any(1))[0]
    return int(c[-1] - c[0] + 1), int(r[-1] - r[0] + 1)


def unscale_box(x0, y0, x1, y1, s, h=None, w=None):
    """성분 외접 상자 → 원래 크기 상자(A11-2): 중심 고정 · 가로 · 세로 ≈ 1/s배.
    반올림 보정: 배율 s 타원으로 그렸을 때 외접 크기가 (x1 − x0, y1 − y0)와 같아지는 정수 상자 크기(중심 홀짝도 같음)를 모두 찾아
    축마다 그 범위의 기하 평균(최소 · 최대의 √곱 — 범위 양 끝에서 IoU 손실이 같아지는 값)을 쓴다. 맞는 크기가 없으면(모양이 타원이 아닌 성분) 단순히 ÷ s.
    s = 1이고 맞는 크기가 그 외접 하나면 그대로. 끝으로 영상 경계 [0, w] × [0, h]로 자른다."""
    W, H = x1 - x0, y1 - y0; cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; px, py = cx % 1, cy % 1
    ws = [k for k in range(max(1, int((W - 2) / s)), int((W + 2) / s) + 2) if (k / 2) % 1 == px]
    hs = [k for k in range(max(1, int((H - 2) / s)), int((H + 2) / s) + 2) if (k / 2) % 1 == py]
    ok = [(a, b) for a in ws for b in hs if _extent(a, b, px, py, s) == (W, H)]
    if ok:
        bw = math.sqrt(min(p[0] for p in ok) * max(p[0] for p in ok)); bh = math.sqrt(min(p[1] for p in ok) * max(p[1] for p in ok))
    else:
        bw, bh = W / s, H / s
    X0, Y0, X1, Y1 = cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2
    if w is not None:
        X0, X1 = max(X0, 0.0), min(X1, float(w))
    if h is not None:
        Y0, Y1 = max(Y0, 0.0), min(Y1, float(h))
    return X0, Y0, X1, Y1


def components(p, t=0.5, max_det=300, connectivity=8, s=1.0):
    """확률 지도 p (h, w) → [[x0, y0, x1, y1, score, 0], …]: p ≥ t 이진화 · 8-연결 성분 · 외접 사각형(연속 좌표) → 1/s 되키움(unscale_box, A11-2) ·
    점수 = 성분 안 p 최댓값 · 넓이 문턱 없음 · 점수 내림차순 위 max_det개."""
    import cv2
    b = (p >= t).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(b, connectivity=connectivity)
    if n <= 1:
        return []
    mx = np.zeros(n, np.float64)
    np.maximum.at(mx, lab.ravel(), p.ravel().astype(np.float64))
    H, W = p.shape; out = []
    for k in range(1, n):
        bx = (float(st[k, 0]), float(st[k, 1]), float(st[k, 0] + st[k, 2]), float(st[k, 1] + st[k, 3]))
        if s != 1.0:
            bx = unscale_box(*bx, s, H, W)
        out.append([*map(float, bx), float(mx[k]), 0.0])
    out.sort(key=lambda r: -r[4])
    return out[:max_det]


# ================================================================ 입력 정규화 (기존 그대로 — ÷255 + ImageNet 상수)
def normalize_fixed(img):
    """U2 고정 상수 정규화(PREREG_U2 4절): uint8 (h, w, 3) → float32 (3, h, w) = (I ÷ 255 − MEAN[c]) ÷ STD[c].
    화소마다 같은 사상이라 「잘라 낸 뒤 정규화 = 정규화 뒤 잘라 냄」이 식으로 성립한다(합성 시험 13-1). 덧댐 0은 정규화 전 화소 0."""
    x = img.astype(np.float32) / np.float32(255.0)
    x = (x - np.array(MEAN, np.float32)) / np.array(STD, np.float32)
    return np.ascontiguousarray(x.transpose(2, 0, 1))


NORMS = {'fixed': normalize_fixed}      # 기존 NORMS에서 'fixed'만 둔다('max'는 쓰지 않는 예전 방식)


# ================================================================ 추론 조각 · 덧댐 · 학습 조각 (기존 그대로. 조각 추론 T는 이 패키지에서 쓰지 않는다 — 출력 규칙 F_0.5 고정)
TILE = 320


TILE_X0 = (0, 160, 320)                                  # 640 폭: 가로 시작


TILE_Y0 = (0, 96, 192)                                   # 512 높이: 세로 시작


def tiles_xy(h, w):
    """T 방식 조각 시작점 [(y0, x0)] — 640×512 영상만(그 밖은 사전 기록에 없음 → 오류)"""
    if (h, w) != (512, 640):
        raise ValueError(f'T 방식은 640×512 입력만 — 받은 크기 {w}×{h}')
    return [(y, x) for y in TILE_Y0 for x in TILE_X0]


def stitch_max(parts, h, w):
    """조각 확률 [(y0, x0, p (320, 320))] → (h, w) · 겹친 곳은 최댓값(PREREG_U2 3절)"""
    out = np.full((h, w), -np.inf, np.float32)
    for y0, x0, p in parts:
        np.maximum(out[y0:y0 + TILE, x0:x0 + TILE], p, out=out[y0:y0 + TILE, x0:x0 + TILE])
    if not np.isfinite(out).all():
        raise ValueError('조각이 영상을 다 덮지 못했다')
    return out


def pad_to(img, mult=32):
    """오른쪽 · 아래를 0으로 덧대 mult의 배수로(추론). 반환 (덧댄 영상, 원 h, 원 w)"""
    h, w = img.shape[:2]; H, W = -(-h // mult) * mult, -(-w // mult) * mult
    if (H, W) == (h, w):
        return img, h, w
    out = np.zeros((H, W) + img.shape[2:], img.dtype); out[:h, :w] = img
    return out, h, w


def crop_flip(img, mask, wmap, size, rng, flip='lr'):
    """학습 입력: 변이 size 미만이면 0으로 덧댐(오른쪽 · 아래, 무게 1 · 마스크 0) → 무작위 size × size 잘라 냄 → 좌우 뒤집기(p 0.5).
    PREREG_U 5-1. (원 코드 RandomCrop은 상하 뒤집기 image[::-1] — 사전 기록대로 좌우를 쓴다. flip='ud'는 원 코드 꼴, 합성 시험용)"""
    h, w = img.shape[:2]
    if h < size or w < size:
        H, W = max(h, size), max(w, size)
        i2 = np.zeros((H, W, 3), img.dtype); i2[:h, :w] = img
        m2 = np.zeros((H, W), mask.dtype); m2[:h, :w] = mask
        w2 = np.ones((H, W), wmap.dtype); w2[:h, :w] = wmap
        img, mask, wmap, h, w = i2, m2, w2, H, W
    top = int(rng.integers(0, h - size + 1)); left = int(rng.integers(0, w - size + 1))
    sl = (slice(top, top + size), slice(left, left + size))
    img, mask, wmap = img[sl], mask[sl], wmap[sl]
    if rng.random() < 0.5:
        ax = 1 if flip == 'lr' else 0
        img, mask, wmap = np.flip(img, ax), np.flip(mask, ax), np.flip(wmap, ax)
    return np.ascontiguousarray(img), np.ascontiguousarray(mask), np.ascontiguousarray(wmap)


# ================================================================ 한 목록 CSV
def list_rows(build, cond, hit_items):
    """hit_items = [(파일명, info(split · boxes))] → 목록 행. 영상 · 라벨은 build/<cond>/images|labels/<split>/<stem>.
    image_sha256 · label_sha256 = 파일 sha256. ignore = HIT-UAV DontCare 상자(연속 좌표, json).
    기존 u_data.list_rows. 고친 곳: HIT-UAV 행만 만든다(다른 학습 데이터를 섞는 인자를 뺐다). HIT-UAV 행의 내용 · 정렬은 같다."""
    rows = []
    for n, v in hit_items:
        st = n[:-4]; ip = f"{cond}/images/{v['split']}/{st}.png"; lp = f"{cond}/labels/{v['split']}/{st}.txt"
        rows.append(dict(stem=st, source='hituav', image=ip, image_sha256=sha_file(os.path.join(build, ip)), label=lp,
                         label_sha256=sha_file(os.path.join(build, lp)), ignore=json.dumps(hit_boxes(v['boxes'], 4))))
    rows.sort(key=lambda r: r['image'])
    return rows


def stem_of_path(p):
    return os.path.splitext(os.path.basename(p.replace('\\', '/')))[0]


def check_row(r):
    """행마다 이름 줄기 단언: 영상 파일 · 라벨 파일 · stem 칸이 같아야 한다(이슈 #4 — 영상과 라벨 목록을 따로 glob하지 않음)"""
    a, b = stem_of_path(r['image']), stem_of_path(r['label'])
    if not (a == b == r['stem']):
        raise AssertionError(f"목록 행 짝 어긋남: 영상 {a} · 라벨 {b} · stem {r['stem']}")


def read_list(path, want_sha=None):
    rows = rcsv(path)
    if want_sha and not hash_ok(sha_file(path), want_sha):
        raise Stop(f'{path}: 목록 sha256이 기록과 다르다')
    for r in rows:
        check_row(r)
    return rows


def load_item(build, r, shape='box', verify=True, s=1.0):
    """목록 한 행 → (영상 uint8 (h, w, 3) RGB, 사람 마스크 uint8, 무게 float32). 파일 바이트를 한 번 읽어 해시와 복호에 같이 쓴다."""
    from PIL import Image
    check_row(r)
    ib = open(os.path.join(build, r['image']), 'rb').read(); lb = open(os.path.join(build, r['label']), 'rb').read()
    if verify and (sha_bytes(ib) != r['image_sha256'] or sha_bytes(lb) != r['label_sha256']):
        raise AssertionError(f"{r['stem']}: 영상 또는 라벨 sha256이 목록과 다르다")
    img = np.asarray(Image.open(io.BytesIO(ib)).convert('RGB'))
    h, w = img.shape[:2]
    m = draw_mask(person_boxes_txt(lb.decode('utf-8'), w, h), h, w, shape, s)
    return img, m, weight_map(m, [tuple(b) for b in json.loads(r['ignore'])], h, w)


# ================================================================ 학습 데이터 · epoch마다 섞는 순서 (기존 그대로)
class U2Dataset:
    """U2 학습 데이터(PREREG_U2 7절): 목록의 PNG · 라벨 파일 바이트를 처음에 한 번 메모리에 올리고(해시는 그때 한 번 대조) 매번 복호한다.
    인덱스 k = epoch × n + i (EpochSampler) — 작업자(지속)가 epoch를 몰라도 (seed, epoch, i)로 같은 잘라 냄 · 뒤집기. 정규화는 고정 상수(4절)."""
    def __init__(self, build, rows, size=320, shape='ellipse', seed=0, flip='lr', dontcare='weight0', scale=0.5, norm='fixed', say=None):
        self.size, self.shape, self.seed, self.flip, self.dc, self.scale = size, shape, seed, flip, dontcare, scale
        self.norm = NORMS[norm]; self.n = len(rows); self.stems = []; self.img, self.lab, self.ign = [], [], []
        nb = 0
        for r in rows:
            check_row(r)
            ib = open(os.path.join(build, r['image']), 'rb').read(); lb = open(os.path.join(build, r['label']), 'rb').read()
            if sha_bytes(ib) != r['image_sha256'] or sha_bytes(lb) != r['label_sha256']:
                raise AssertionError(f"{r['stem']}: 영상 또는 라벨 sha256이 목록과 다르다")
            self.img.append(ib); self.lab.append(lb.decode('utf-8')); self.ign.append([tuple(b) for b in json.loads(r['ignore'])])
            self.stems.append(r['stem']); nb += len(ib)
        self.bytes = nb
        if say:
            say(f'  학습 PNG {self.n}장 메모리 적재 {nb / 1e9:.2f} GB(파일 바이트) · 해시 대조 끝')

    def __len__(self):
        return self.n

    def item(self, i, ep):
        """(영상 uint8 잘라 낸 것, 마스크, 무게) — 정규화 전(합성 시험이 씀)"""
        from PIL import Image
        img = np.asarray(Image.open(io.BytesIO(self.img[i])).convert('RGB'))
        h, w = img.shape[:2]
        m = draw_mask(person_boxes_txt(self.lab[i], w, h), h, w, self.shape, self.scale)
        wm = weight_map(m, self.ign[i], h, w) if self.dc == 'weight0' else np.ones((h, w), np.float32)
        rng = np.random.default_rng([self.seed, ep, i])
        return crop_flip(img, m, wm, self.size, rng, self.flip)

    def __getitem__(self, k):
        import torch
        ep, i = divmod(int(k), self.n)
        img, m, wm = self.item(i, ep)
        return torch.from_numpy(self.norm(img)), torch.from_numpy(m[None].astype(np.float32)), torch.from_numpy(wm[None])


class EpochSampler:
    """epoch마다 torch.randperm(n, Generator(seed × 100003 + epoch)) 순서 — 폐기본 u의 DataLoader(shuffle=True, generator=g)와 같은 순열.
    내는 값은 epoch × n + i(작업자를 살려 두어도 epoch가 전해짐)."""
    def __init__(self, n, seed):
        self.n, self.seed, self.epoch = n, int(seed), 0

    def set_epoch(self, ep):
        self.epoch = int(ep)

    def __len__(self):
        return self.n

    def __iter__(self):
        import torch
        g = torch.Generator(); g.manual_seed(self.seed * 100003 + self.epoch)
        return iter((self.epoch * self.n + int(i)) for i in torch.randperm(self.n, generator=g).tolist())
