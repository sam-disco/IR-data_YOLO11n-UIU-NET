"""UIU-Net 실행 — 원 저장소 받기 → 입력 둘(원영상 · 제안 필터) × 정답 마스크 둘(0.5배 타원 · 상자 채움) × seed 0 학습 4회 → 출력 규칙 F_0.5로 배포 분할 test · val 평가.
기존 저장소 IR-night-filter(14차 수정4) src/irfilter/u2_stage.py의 학습 · 추론 · 상자 변환 · 평가 부분에서 옮겼다.
「그대로」 구역의 함수는 바이트까지 같고, 그 아래 함수는 설명에 고친 곳을 적었다(대응표 docs/FILE_MAP.md).

UIU-Net은 화소마다 「사람인가」를 내는 분할 모형이라 정답이 마스크여야 한다. HIT-UAV에는 상자만 있어서 상자로 마스크를 만든다. 두 가지를 돌린다:
  ellipse  사람 상자에 내접한 타원을 0.5배로 줄인 것(지금까지의 방식 — 붙어 있는 사람이 한 덩어리로 합쳐지는 것을 줄인다). 출력 상자는 1/0.5로 되키운다
  box      상자 안을 그대로 채운 것(가장 단순한 방식 — 상자가 닿은 사람들은 한 덩어리가 된다). 출력 상자는 그대로
출력 규칙 F_0.5(고정 — 다시 고르지 않는다): 영상 전체 추론 · 문턱 0.5 · 8-연결 성분 · 외접 상자 · 점수 = 성분 안 최대 확률.
끝난 학습 · 평가는 건너뛰고, 끊긴 학습은 같은 명령으로 epoch 단위에서 이어 간다."""
import collections, csv, datetime, os, time
import numpy as np
from common import Stop, now, sha_file, wjson, wcsv, rjson, dump_gz
from common import hituav as D, metrics as M
from . import u_data as UD

PROGRESS = ['logged_at', 'step', 'name', 'seconds', 'status', 'last_sha256', 'eval_sha256', 'note']


# ================================================================ 경로 (고친 것 — 기존 P(cfg)는 설정에서 경로를 만들었다. 여기서는 run_all.py가 넣어 준다)
def P(cfg):
    """dict(res, evals, logs, runs, build, view, root): build = 입력 영상 폴더 · view = 학습 목록 폴더 · root = 푼 HIT-UAV 폴더"""
    return cfg['_P']


def variant(cfg, mask):
    """정답 마스크 방식 하나(u2.masks의 이름)를 고른 설정 — u2.train의 mask · mask_scale만 그 방식의 값으로 바꾼 사본. 학습 · 추론 함수는 이 사본을 읽는다."""
    U = cfg['u2']; return dict(cfg, u2=dict(U, train=dict(U['train'], **U['masks'][mask])))


def u_name(mask, cond, s):
    return f'uiunet_{mask}_{cond}_s{s}'


def run_dir(cfg, mask, cond, s):
    return os.path.join(P(cfg)['runs'], u_name(mask, cond, s))


def eval_path(cfg, mask, cond, s, split):
    return os.path.join(P(cfg)['evals'], f'{u_name(mask, cond, s)}_{split}.json.gz')


# ================================================================ 기존 u2_stage.py 그대로
def dev_of(cfg):
    import torch
    return torch.device(f"cuda:{cfg['device']}" if str(cfg['device']) != 'cpu' and torch.cuda.is_available() else 'cpu')


def rule_parse(name):
    m, t = name.split('_'); return m, float(t)


def read_png(path):
    from PIL import Image
    return np.asarray(Image.open(path).convert('RGB'))


def person_diag(p, boxes, pad=4):
    """2절 (나): 사람(Person) 상자마다 상자 안 p 최댓값 · 영상의 「사람 상자를 pad px 넓힌 바깥」 p 최댓값(바깥이 없으면 None)"""
    h, w = p.shape; inside = []; m = np.zeros((h, w), bool)
    for c, x, y, bw, bh in boxes:
        if c != 0:
            continue
        x0, y0, x1, y1 = max(x, 0), max(y, 0), min(x + bw, w), min(y + bh, h)
        if x1 > x0 and y1 > y0:
            inside.append(float(p[y0:y1, x0:x1].max()))
        m[max(y - pad, 0):min(y + bh + pad, h), max(x - pad, 0):min(x + bw + pad, w)] = True
    return inside, (float(p[~m].max()) if (~m).any() else None)


def predict_rules(cfg, net, dev, stems, read, gt, rules, diag=True):
    """stems 차례로 추론 한 번 → 규칙마다 상자 {규칙: {stem: [[x0,y0,x1,y1,점수,0]…]}} · 진단 {방식: dict(person=[…], outside=[…])}"""
    from . import u_net as UN
    I = cfg['u2']; s = I['train']['mask_scale']; modes = sorted({m for _, m, _ in rules})
    preds = {r: {} for r, _, _ in rules}; dg = {m: dict(person=[], outside=[]) for m in modes}
    for st in stems:
        pm = UN.prob_maps(net, read(st), dev, modes, I['tile_batch'])
        for r, m, t in rules:
            preds[r][st] = UD.components(pm[m], t, I['max_det'], I['connectivity'], s)
        if diag:
            for m in modes:
                a, b = person_diag(pm[m], gt[st + '.jpg']['boxes'])
                dg[m]['person'] += a
                if b is not None:
                    dg[m]['outside'].append(b)
    return preds, dg


def q3(v):
    v = [x for x in v if x is not None]
    return dict(n=len(v), p10=float(np.percentile(v, 10)) if v else None, p50=float(np.percentile(v, 50)) if v else None,
                p90=float(np.percentile(v, 90)) if v else None)


def diag_summary(dg):
    return {m: dict(person_max=q3(d['person']), outside_max=q3(d['outside'])) for m, d in dg.items()}


def ap_rule(preds, gt, stems):
    """한 규칙 → Person AP50(점) · 사람 있는 영상 중 상자가 하나 이상 나온 비율(%)"""
    Dl, Tl = [], []; has = got = 0
    for st in stems:
        q = np.array(preds[st], float).reshape(-1, 6); bx = [tuple(b) for b in gt[st + '.jpg']['boxes']]
        d, tg = M.image_records(q[:, :4], q[:, 4], q[:, 5], bx); Dl.append(d); Tl.append(tg)
        if any(b[0] == 0 for b in bx):
            has += 1; got += len(preds[st]) > 0
    ap = M.ap_table(Dl, Tl)['Person']['AP50']
    return dict(AP50=None if ap is None else 100 * ap, img_with_box_pct=100 * got / max(has, 1), person_imgs=has)


def eval_set(cfg, net, dev, stems, read, gt, rules, diag=True):
    t0 = time.time(); preds, dg = predict_rules(cfg, net, dev, stems, read, gt, rules, diag)
    res = {r: ap_rule(preds[r], gt, stems) for r, _, _ in rules}
    return dict(rules=res, diag=diag_summary(dg) if diag else None, seconds=time.time() - t0), preds


def eval_file(cfg, net, dev, name, seed, split, fold, gt, src, build, cond, wsha, path, rules, diag=True):
    """HIT-UAV 평가 파일(u2 꼴): preds_rules = {규칙: {stem: 상자}} · rules_ap · diag. metrics.load 대신 rule_runs가 읽는다."""
    stems = sorted(k[:-4] for k in gt)
    read = lambda st: read_png(os.path.join(build, cond, 'images', src[st + '.jpg'].get('split', split), st + '.png'))
    r, preds = eval_set(cfg, net, dev, stems, read, gt, rules, diag)
    res = dict(cond=name, seed=seed, split=split, fold=fold, ratio=1.0, model_kind='uiunet_u2', weights_sha256=wsha, norm='fixed',
               mask_scale=cfg['u2']['train']['mask_scale'], rules=[x[0] for x in rules], rules_ap=r['rules'], diag=r['diag'], preds_rules=preds,
               seconds=r['seconds'], at=now())
    dump_gz(path, res)
    return res


def rule_runs(paths, gt, rule):
    """u2 평가 파일들 → runs[이름][seed] = {stem: (dets, targets)} — metrics.load와 같은 image_records(규칙 하나의 상자)"""
    runs = collections.defaultdict(dict)
    for p in paths:
        e = M.read_eval(p)
        if rule not in e['preds_rules']:
            raise Stop(f'{os.path.basename(p)}에 규칙 {rule}의 상자가 없다')
        recs = {}
        for s, b in e['preds_rules'][rule].items():
            q = np.array(b, float).reshape(-1, 6)
            recs[s] = M.image_records(q[:, :4], q[:, 4], q[:, 5], [tuple(x) for x in gt[s + '.jpg']['boxes']])
        runs[e['cond']][e['seed']] = recs
    return runs


# ================================================================ 고친 것
def gt_src(cfg, split):
    """평가 정답 · 원본 정보 — 배포 분할 하나(info['split'] = PNG가 놓인 저장 폴더).
    기존 u2_stage.gt_src. 고친 곳: 날짜 분할 · 접기 대신 배포 분할 목록을 쓴다. 반환 꼴은 같다."""
    src = D.official_lists(P(cfg)['root'], cfg['paths']['split_csv'])[split]
    return {n: dict(date=v['date'], folder=v['folder'], boxes=v['boxes']) for n, v in src.items()}, src


def make_view(cfg, cond, out=print):
    """data/build_view/official/<조건>/LIST_U.csv(배포 train — 행마다 영상 · 라벨 · 해시 · DontCare) · VIEW.json
    기존 u2_stage.make_view · view_items. 고친 곳: 학습 목록 = 배포 train(날짜 접기 · 다른 학습 데이터 가지를 뺐다). 행의 내용 · 정렬은 같다."""
    Pp = P(cfg); B = Pp['build']; V = os.path.join(Pp['view'], 'official', cond); rec = os.path.join(V, 'VIEW.json')
    if os.path.exists(rec):
        return rjson(rec)
    trn = sorted(D.official_lists(Pp['root'], cfg['paths']['split_csv'])['train'].items()); os.makedirs(V, exist_ok=True)
    miss = [n for n, v in trn if not os.path.exists(os.path.join(B, cond, 'images', v['split'], n[:-4] + '.png'))]
    if miss:
        raise Stop(f'{cond}: 입력 영상 없음 {len(miss)}장 (예 {miss[:2]})')
    rows = UD.list_rows(B, cond, trn); lp = os.path.join(V, 'LIST_U.csv'); wcsv(lp, UD.LIST_COLS, rows)
    r = dict(training='official', cond=cond, train=len(rows), list_sha256=sha_file(lp))
    wjson(rec, r); out(f'학습 목록 {cond}: 배포 train {len(rows)}장 · 목록 {r["list_sha256"][:8]}…')
    return r


def list_rows(cfg, cond, out=print):
    """학습 목록 LIST_U.csv(없으면 만든다)와 그 기록 — 목록 sha256이 기록과 다르면 멈춘다.
    기존 u2_stage.view_rows. 고친 곳: 사전 점검 단계가 적어 둔 해시와의 대조를 뺐다(목록 파일과 그 기록의 대조는 그대로)."""
    v = make_view(cfg, cond, out); lp = os.path.join(P(cfg)['view'], 'official', cond, 'LIST_U.csv')
    return UD.read_list(lp, v['list_sha256']), v


def ulog(cfg, **kw):
    """진행 기록 results/uiunet/logs/progress.csv (기존 u2_stage.ulog의 꼴을 줄인 것)"""
    p = os.path.join(P(cfg)['logs'], 'progress.csv'); os.makedirs(os.path.dirname(p), exist_ok=True); new = not os.path.exists(p)
    with open(p, 'a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, PROGRESS)
        if new:
            w.writeheader()
        w.writerow({k: kw.get(k, '') for k in PROGRESS} | {'logged_at': now()})


def set_aside(rd, out):
    """반쯤 남은 학습 폴더(이어 갈 ckpt가 없음)를 지우지 않고 이름을 바꿔 둔다 → 그 학습은 처음부터 다시 한다"""
    dst = f"{rd}__partial_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.rename(rd, dst); out(f'  반쯤 남은 학습 폴더를 옮겨 둠(지우지 않음): {dst}')


def run_one(cfg, out, mask, cond, s, stopper=None):
    """학습 한 번(없으면 · 끊긴 것은 이어 감). 반환 run_record.
    기존 u2_stage.run_one. 고친 곳: ① 정밀도 · 배치 · 손실을 사전 단계 상태가 아니라 설정(u2.precision · batch · loss — 기존 실행 값 FP32 · 4 · A)에서 읽는다
    ② 일정 · 시간 한도 확인을 뺐다 ③ 학습 도중의 검증 기록을 뺐다 ④ 반쯤 남은 폴더는 멈추지 않고 옮겨 둔 뒤 다시 한다 ⑤ 학습 목록 = 배포 train ·
    정답 마스크 방식(mask)을 인자로 받는다. UN.train_run2에 넘기는 값의 꼴은 같다."""
    from . import u_net as UN
    vc = variant(cfg, mask); U = vc['u2']; prec, batch, loss = U['precision'], U['batch'], U['loss']; rd = run_dir(cfg, mask, cond, s); st = UN.run_state(rd)
    name = u_name(mask, cond, s)
    if st == 'done':
        return rjson(os.path.join(rd, 'run_record.json'))
    if st == 'partial':
        set_aside(rd, out)
    rows, v = list_rows(cfg, cond, out); T = U['train']
    out(f'---- UIU-Net 학습 {name} (배포 train {len(rows)}장 · 마스크 {T["mask"]} × {T["mask_scale"]} · {prec} · 배치 {batch} · 손실 {loss})'); t0 = time.time()
    try:
        rec = UN.train_run2(dict(vc, _u_list_sha=v['list_sha256']), T, rows, P(cfg)['build'], rd, s, T['epochs'], prec, loss, batch,
                            0, None, (), out, stopper=stopper)
        ulog(cfg, step='train', name=name, seconds='%.0f' % (time.time() - t0), status='ok', last_sha256=rec['last_sha256'])
    except UN.NonFinite as e:
        ulog(cfg, step='train', name=name, seconds='%.0f' % (time.time() - t0), status='fail', note='NaN/Inf')
        raise Stop(f'손실 NaN/Inf — 멈춤: {e}')
    except Exception as x:
        ulog(cfg, step='train', name=name, seconds='%.0f' % (time.time() - t0), status='fail', note=repr(x)[:300]); raise
    return rec


def eval_one(cfg, out, mask, cond, s, split, rules):
    """학습이 끝난 모형 → 평가 파일(이미 같은 가중치 · 규칙으로 있으면 건너뜀).
    기존 u2_stage.eval_one. 고친 곳: ① 다른 가중치로 만든 평가 파일이 남아 있으면 멈추지 않고 옮겨 둔 뒤 다시 평가한다 ② 평가 집합 = 배포 분할 하나 ③ 진행 기록 꼴.
    평가(eval_file)에 넘기는 값의 꼴은 같다 — 출력 상자의 되키움 배율은 그 학습의 마스크 배율이다."""
    from . import u_net as UN
    vc = variant(cfg, mask); rd = run_dir(cfg, mask, cond, s); rec = rjson(os.path.join(rd, 'run_record.json')); ep = eval_path(cfg, mask, cond, s, split); name = u_name(mask, cond, s)
    if os.path.exists(ep):
        e = M.read_eval(ep)
        if e['weights_sha256'] == rec['last_sha256'] and e['rules'] == [r[0] for r in rules]:
            return ep
        os.rename(ep, f"{ep}.old_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}")
        out(f'  다른 가중치로 만든 평가 파일을 옮겨 둠: {os.path.basename(ep)}')
    gt, src = gt_src(cfg, split); dev = dev_of(cfg); t0 = time.time()
    out(f'---- UIU-Net 평가 {name} · 배포 {split} {len(gt)}장')
    net = UN.load_net(vc, os.path.join(rd, 'last.pth'), dev)
    eval_file(vc, net, dev, name, s, split, 'official', gt, src, P(cfg)['build'], cond, rec['last_sha256'], ep, rules, diag=True)
    ulog(cfg, step='eval', name=f'{name}_{split}', seconds='%.0f' % (time.time() - t0), status='ok', eval_sha256=sha_file(ep))
    return ep


def ap_of(cfg, mask, cond, s, split):
    """평가 파일을 출력 규칙 하나로 다시 채점한 Person AP50(0 ~ 1). 기존 u2_stage.ap_seeds의 셈(rule_runs → metrics.ap_on)"""
    gt, _ = gt_src(cfg, split); stems = sorted(k[:-4] for k in gt)
    runs = rule_runs([eval_path(cfg, mask, cond, s, split)], gt, cfg['u2']['rule']); (nm, sd), = runs.items()
    return M.ap_on(sd[s], stems, 'Person')


# ================================================================ 새 코드 — 차례로 돌리기
def jobs(cfg):
    """[(마스크, 조건, seed)] — 마스크 방식 바깥 · 조건 안쪽"""
    return [(m, c, s) for s in cfg['u2']['seeds'] for m in cfg['u2']['masks'] for c in cfg['u2']['conds']]


def todo(cfg):
    """아직 끝나지 않은 학습 수"""
    from . import u_net as UN
    return sum(UN.run_state(run_dir(cfg, m, c, s)) != 'done' for m, c, s in jobs(cfg))


def run(cfg, out, est=None):
    from . import u_net as UN
    rule = cfg['u2']['rule']; R = [(rule, *rule_parse(rule))]
    UN.fetch(cfg, out)
    for m, c, s in jobs(cfg):
        fresh = UN.run_state(run_dir(cfg, m, c, s)) != 'done'; t0 = time.time(); tick = [time.time()]

        def stopper(ep):
            if est:
                est.epoch('uiunet', ep, time.time() - tick[0], cfg['u2']['train']['epochs'], todo(cfg))
            tick[0] = time.time()
            return None
        run_one(cfg, out, m, c, s, stopper)
        for sp in cfg['split']['eval']:
            eval_one(cfg, out, m, c, s, sp, R)
        if est and fresh:
            est.run_done('uiunet', time.time() - t0, todo(cfg))
    out('UIU-Net 끝')
