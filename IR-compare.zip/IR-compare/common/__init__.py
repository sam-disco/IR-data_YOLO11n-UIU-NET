"""IR-compare 공용 도구 — 해시 · 파일 읽고 쓰기 · 멈춤 예외 · 기록.
아래 함수는 기존 저장소 IR-night-filter(14차 수정4) src/irfilter/__init__.py의 것을 그대로 옮긴 것이다(대응표 docs/FILE_MAP.md)."""
import csv, datetime, gzip, hashlib, json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # 패키지 뿌리(run_all.py가 있는 폴더)


class Stop(Exception):
    """사전 기록 · 해시 조건이 어긋나 멈출 때. run.py가 「!! 멈춤:」으로 출력하고 종료 코드 2로 끝낸다."""


def now():
    return datetime.datetime.now().isoformat(timespec='seconds')


def sha_file(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def arr_sha(a):
    """화소 배열 해시 — data.arr_sha · h2_common.arr_sha · j_common.arr_sha와 같은 정의(연속 배열 바이트의 sha256)"""
    import numpy as np
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def hash_ok(h, want):
    """want = 64자리, 또는 장부처럼 앞자리만 · 「앞…뒤」 꼴"""
    if '…' in want:
        a, b = want.split('…')
        return h.startswith(a) and h.endswith(b)
    return h == want if len(want) == 64 else h.startswith(want)


def wjson(p, obj):
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    t = p + '.tmp'
    with open(t, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1, default=float)
    os.replace(t, p)


def rjson(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def dump_gz(p, obj):
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    t = p + '.tmp'
    with gzip.open(t, 'wt', encoding='utf-8') as f:
        json.dump(obj, f)
    os.replace(t, p)            # 끊겨도 반쯤 쓴 파일이 이름을 차지하지 않는다


def load_gz(p):
    with gzip.open(p, 'rt', encoding='utf-8') as f:
        return json.load(f)


def wcsv(p, cols, rows):
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    with open(p, 'w', newline='\n', encoding='utf-8') as f:
        w = csv.DictWriter(f, cols, lineterminator='\n'); w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in cols})


def rcsv(p):
    with open(p, encoding='utf-8') as f:
        return list(csv.DictReader(f))


class Log:
    """화면과 파일에 함께 쓴다"""
    def __init__(self, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.path = path

    def __call__(self, *a):
        s = ' '.join(str(x) for x in a)
        print(s, flush=True)
        with open(self.path, 'a', encoding='utf-8') as f:
            f.write(f'[{now()}] {s}\n')
