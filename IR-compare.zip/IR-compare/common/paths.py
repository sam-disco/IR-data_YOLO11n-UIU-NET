"""경로 확인 — 한글 · 띄어쓰기가 든 경로면 안내하고 멈춘다(Ultralytics · OpenCV가 그런 경로에서 영상을 못 읽는 일이 있다)."""
import os
from . import Stop


def path_problem(p):
    """절대 경로에 ASCII가 아닌 글자(한글 등)나 띄어쓰기가 있으면 그 사유, 없으면 None"""
    a = os.path.abspath(p)
    if any(ord(ch) > 127 for ch in a):
        return f'경로에 한글 등 영문이 아닌 글자가 있다: {a}'
    if any(ch.isspace() for ch in a):
        return f'경로에 띄어쓰기가 있다: {a}'
    return None


def check_paths(**named):
    """named = {설명: 경로}. 문제가 있으면 안내하고 멈춘다."""
    bad = [f'{k} — {path_problem(v)}' for k, v in named.items() if path_problem(v)]
    if bad:
        raise Stop('경로를 바꿔야 한다. ' + ' / '.join(bad) +
                   ' → 영문 · 숫자 · 밑줄 · 하이픈만 있는 경로(예: C:\\work\\IR-compare, /home/<이름>/IR-compare)로 옮긴 뒤 같은 명령을 다시 실행한다')
