"""Person AP50 채점기 — 매칭 · AP(101점 보간) · 동작점 · 선 구조 위 오검출. 모델 · torch 없이 numpy(와 scipy)만으로 돈다.
기존 저장소 IR-night-filter(14차 수정4) src/irfilter/metrics.py의 채점 함수를 그대로 옮긴 것이다(판정 · 선정 함수는 옮기지 않았다. 대응표 docs/FILE_MAP.md).

채점 정의: 확신도 순 · 남은 정답 중 IoU 최대 · DontCare IoA ≥ 0.5 미매칭 제외 · [0, r, r끝, 1] 포락선 · 101점.
정답은 HIT-UAV b53106c normal_json이다."""
import collections, gzip, json
import numpy as np

IOUV = np.linspace(0.5, 0.95, 10)                                                  # IoU 0.50:0.05:0.95


BINS = [(0, 8, '<=8'), (9, 12, '9-12'), (13, 16, '13-16'), (17, 10 ** 9, '>=17')]  # Person 짧은 변(px) 구간


NAMES = {0: 'Person', 1: 'Car', 2: 'Bicycle', 3: 'OtherVehicle'}


# ---------------- 매칭 ----------------
def iou_mat(a, b):
    """a (M,4), b (N,4) xyxy → (M,N)"""
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)))
    tl = np.maximum(a[:, None, :2], b[None, :, :2]); br = np.minimum(a[:, None, 2:], b[None, :, 2:])
    inter = np.clip(br - tl, 0, None).prod(2)
    aa = (a[:, 2:] - a[:, :2]).prod(1); ab = (b[:, 2:] - b[:, :2]).prod(1)
    return inter / (aa[:, None] + ab[None, :] - inter + 1e-16)


def ioa(pred, dc):
    """검출 면적 대비 DontCare 상자와 겹친 면적의 최댓값 (N,)"""
    if len(pred) == 0 or len(dc) == 0:
        return np.zeros(len(pred))
    tl = np.maximum(pred[:, None, :2], dc[None, :, :2]); br = np.minimum(pred[:, None, 2:], dc[None, :, 2:])
    inter = np.clip(br - tl, 0, None).prod(2)
    return (inter / ((pred[:, 2:] - pred[:, :2]).prod(1)[:, None] + 1e-16)).max(1)


def match(pcls, tcls, iou):
    """Ultralytics validator와 같은 탐욕 매칭(검출은 신뢰도 내림차순). iou (M 정답, N 검출).
    반환 correct (N,10) · m50 (N,) IoU 0.5에서 잡은 정답 번호(−1 없음)"""
    N = len(pcls); correct = np.zeros((N, 10), bool); m50 = np.full(N, -1)
    if N == 0 or len(tcls) == 0:
        return correct, m50
    iou = iou * (tcls[:, None] == pcls[None, :])
    matched = np.zeros((len(tcls), 10), bool)
    for j in np.flatnonzero((iou >= IOUV.min()).any(0)):
        avail = np.where(matched, 0, iou[:, j, None]); k = avail.argmax(0)
        correct[j] = avail[k, range(10)] >= IOUV
        matched[k, range(10)] |= correct[j]
        if correct[j, 0]: m50[j] = k[0]
    return correct, m50


def image_records(pred_xyxy, pred_conf, pred_cls, gt_boxes):
    """영상 한 장. gt_boxes [(cls, x, y, w, h)] 원 정수 상자. DontCare 무시: IoU 0.5 미매칭이고 DontCare IoA ≥ 0.5."""
    gt = np.array([b for b in gt_boxes if b[0] in NAMES], float).reshape(-1, 5)
    dc = np.array([b for b in gt_boxes if b[0] == 4], float).reshape(-1, 5)
    t_xyxy = np.c_[gt[:, 1], gt[:, 2], gt[:, 1] + gt[:, 3], gt[:, 2] + gt[:, 4]]
    d_xyxy = np.c_[dc[:, 1], dc[:, 2], dc[:, 1] + dc[:, 3], dc[:, 2] + dc[:, 4]]
    o = np.argsort(-pred_conf, kind='stable')
    px, pc, pk = pred_xyxy[o].reshape(-1, 4), pred_conf[o], pred_cls[o].astype(int)
    correct, m50 = match(pk, gt[:, 0].astype(int), iou_mat(t_xyxy, px))
    ign = (~correct[:, 0]) & (ioa(px, d_xyxy) >= 0.5)
    dets = dict(xyxy=px, conf=pc, cls=pk, correct=correct, m50=m50, ignored=ign)
    tg = dict(cls=gt[:, 0].astype(int), short=np.minimum(gt[:, 3], gt[:, 4]), xyxy=t_xyxy)
    return dets, tg


# ---------------- AP ----------------
_X101 = np.linspace(0, 1, 101)


def _ap_per_class(tp, conf, pred_cls, target_cls, eps=1e-16):
    """Ultralytics 8.4.200 utils/metrics.py ap_per_class의 AP 부분만 같은 순서로 옮김. 반환 ap (nc, 10), 클래스"""
    i = np.argsort(-conf)                                   # 원본과 같은 기본 정렬(동점 순서까지 같게)
    tp, conf, pred_cls = tp[i], conf[i], pred_cls[i]
    uc, nt = np.unique(target_cls, return_counts=True)
    ap = np.zeros((uc.shape[0], tp.shape[1]))
    for ci, c in enumerate(uc):
        i = pred_cls == c
        if i.sum() == 0 or nt[ci] == 0:
            continue
        fpc = (1 - tp[i]).cumsum(0); tpc = tp[i].cumsum(0)
        recall = tpc / (nt[ci] + eps); precision = tpc / (tpc + fpc)
        for j in range(tp.shape[1]):
            r, p = recall[:, j], precision[:, j]
            mrec = np.concatenate(([0.0], r, [r[-1] if len(r) else 1.0], [1.0]))
            mpre = np.flip(np.maximum.accumulate(np.flip(np.concatenate(([1.0], p, [0.0], [0.0])))))
            ap[ci, j] = np.trapezoid(np.interp(_X101, mrec, mpre), _X101)
    return ap, uc.astype(int)


def ap_table(dets_list, tg_list):
    """영상별 기록 목록 → {클래스: dict(n, AP50, AP50_95)}. 정답 0개 클래스는 AP None."""
    keep = [~d['ignored'] for d in dets_list]
    tp = np.concatenate([d['correct'][k] for d, k in zip(dets_list, keep)] or [np.zeros((0, 10), bool)])
    conf = np.concatenate([d['conf'][k] for d, k in zip(dets_list, keep)] or [np.zeros(0)])
    pcls = np.concatenate([d['cls'][k] for d, k in zip(dets_list, keep)] or [np.zeros(0)])
    tcls = np.concatenate([t['cls'] for t in tg_list] or [np.zeros(0)])
    out = {NAMES[c]: dict(n=int((tcls == c).sum()), AP50=None, AP50_95=None) for c in NAMES}
    if len(tcls) == 0:
        return out
    ap, uc = _ap_per_class(tp, conf, pcls, tcls)
    for i, c in enumerate(uc):
        out[NAMES[int(c)]].update(AP50=float(ap[i, 0]), AP50_95=float(ap[i].mean()))
    return out


# ---------------- 동작점 · 선 구조 ----------------
def operating_points(dets_list, tg_list, n_img, fppi=0.5, conf_fixed=0.25, min_fp=20):
    """Person. A = 영상당 오탐 fppi 고정(문턱은 조건·seed마다) · B = 신뢰도 conf_fixed 고정. 재현율은 IoU 0.5, 크기 구간별."""
    conf, fp, tgt = [], [], []
    for i, (d, t) in enumerate(zip(dets_list, tg_list)):
        k = (d['cls'] == 0) & ~d['ignored']
        conf.append(d['conf'][k]); fp.append(~d['correct'][k, 0]); tgt.append(np.c_[np.full(k.sum(), i), d['m50'][k]])
    conf = np.concatenate(conf); fp = np.concatenate(fp); tgt = np.concatenate(tgt)
    o = np.argsort(-conf, kind='stable'); conf, fp, tgt = conf[o], fp[o], tgt[o]
    cfp = np.cumsum(fp); lim = int(np.floor(fppi * n_img))
    nA = int(np.searchsorted(cfp, lim, side='right'))
    while nA > 0 and nA < len(conf) and conf[nA - 1] == conf[nA]:
        nA -= 1                                             # 같은 신뢰도는 함께 넣거나 함께 뺀다
    nB = int((conf >= conf_fixed).sum())
    res = {}
    for name, n, thr in (('A_fppi%.2g' % fppi, nA, float(conf[nA - 1]) if nA else None), ('B_conf%.2g' % conf_fixed, nB, conf_fixed)):
        hit = {(int(a), int(b)) for a, b in tgt[:n][~fp[:n]]}
        nfp = int(fp[:n].sum())
        row = dict(conf_thr=thr, n_fp=nfp, fp_per_img=nfp / n_img, reported=(nfp >= min_fp) if name.startswith('A') else True, bins={})
        allh = alln = 0
        for lo, hi, lab in BINS:
            ids = [(i, j) for i, t in enumerate(tg_list) for j in np.flatnonzero((t['cls'] == 0) & (t['short'] >= lo) & (t['short'] <= hi))]
            h = sum((i, j) in hit for i, j in ids); allh += h; alln += len(ids)
            row['bins'][lab] = dict(n=len(ids), recall=(h / len(ids)) if ids else None)
        row['recall_all'] = allh / alln if alln else None; row['n_person'] = alln
        res[name] = row
    return res


def on_line(I, box):
    """「선 구조 위」(PREREG_F §4.6): 상자 중심 창(한 변 max(41, 4×긴 변+1)), 문턱 = (창 중앙값 + 상자 안 최댓값)/2,
    상자 안 최댓값 화소의 8연결 덩어리 공분산 고윳값 λ1 ≥ λ2. √(λ1/max(λ2, 1/12)) ≥ 3 이고 4√λ1 ≥ 2×긴 변이면 참."""
    from scipy import ndimage
    H, W = I.shape; x0, y0, x1, y1 = box
    L = max(x1 - x0, y1 - y0); h = max(20, int(np.ceil(2 * L)))
    cx, cy = int((x0 + x1) / 2), int((y0 + y1) / 2)
    wx0, wy0, wx1, wy1 = max(cx - h, 0), max(cy - h, 0), min(cx + h + 1, W), min(cy + h + 1, H)
    win = I[wy0:wy1, wx0:wx1].astype(float)
    bx0, by0 = max(int(np.floor(x0)) - wx0, 0), max(int(np.floor(y0)) - wy0, 0)
    bx1, by1 = min(int(np.ceil(x1)) - wx0, win.shape[1]), min(int(np.ceil(y1)) - wy0, win.shape[0])
    if win.size == 0 or bx1 <= bx0 or by1 <= by0:
        return False
    sub = win[by0:by1, bx0:bx1]; sy, sx = np.unravel_index(np.argmax(sub), sub.shape)
    t = (np.median(win) + sub.max()) / 2
    if sub.max() <= np.median(win):
        return False
    lab, _ = ndimage.label(win >= t, structure=np.ones((3, 3)))
    ys, xs = np.nonzero(lab == lab[by0 + sy, bx0 + sx])
    if len(ys) < 2:
        return False
    ev = np.sort(np.linalg.eigvalsh(np.cov(np.c_[xs, ys].T)))[::-1]
    return bool(np.sqrt(ev[0] / max(ev[1], 1 / 12)) >= 3 and 4 * np.sqrt(ev[0]) >= 2 * L)


def summarize(stems, preds, gt, orig=None):
    """평가 파일의 summary. preds {stem: [[x0,y0,x1,y1,conf,cls], …]}. orig(stem) → 원영상 I(선 구조 위 오탐을 셀 때만)."""
    D, T = [], []
    for s in stems:
        p = np.array(preds[s], float).reshape(-1, 6)
        d, t = image_records(p[:, :4], p[:, 4], p[:, 5], [tuple(b) for b in gt[s + '.jpg']['boxes']])
        D.append(d); T.append(t)
    out = dict(n_img=len(stems), ap=ap_table(D, T), op=operating_points(D, T, len(stems)))
    if orig:
        thr = out['op']['A_fppi0.5']['conf_thr'] or 1.0
        c = dict(fp=0, fp_line=0, tp=0, tp_line=0)
        for s, d in zip(stems, D):
            k = np.flatnonzero((d['cls'] == 0) & ~d['ignored'] & (d['conf'] >= thr))
            if len(k) == 0: continue
            I = orig(s)
            for j in k:
                key = 'tp' if d['correct'][j, 0] else 'fp'; c[key] += 1; c[key + '_line'] += on_line(I, d['xyxy'][j])
        out['line'] = c
    return out


# ---------------- 평가 파일 읽기 ----------------
def read_eval(p):
    with gzip.open(p, 'rt', encoding='utf-8') as f:
        return json.load(f)


def load(paths, gt):
    """평가 파일들 → runs[cond][seed] = {stem: (dets, targets)}, evals[(cond, seed)] = summary"""
    runs, evals = collections.defaultdict(dict), {}
    for p in paths:
        r = read_eval(p); recs = {}
        for s in sorted(r['preds']):
            q = np.array(r['preds'][s], float).reshape(-1, 6)
            recs[s] = image_records(q[:, :4], q[:, 4], q[:, 5], [tuple(b) for b in gt[s + '.jpg']['boxes']])
        runs[r['cond']][r['seed']] = recs; evals[(r['cond'], r['seed'])] = r['summary']
    return runs, evals


def ap_on(recs, stems, cls='Person', key='AP50'):
    return ap_table([recs[s][0] for s in stems], [recs[s][1] for s in stems])[cls][key]


def mean_sd(v):
    v = [x for x in v if x is not None]
    return dict(mean=float(np.mean(v)) if v else None, sd=float(np.std(v, ddof=1)) if len(v) > 1 else None, seeds=v, n=len(v))
