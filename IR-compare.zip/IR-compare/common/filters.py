"""제안 필터 — uint8 2차원 영상 I(H, W) → 필터 출력 P(uint8, 같은 크기).
기존 저장소 IR-night-filter(14차 수정4) src/irfilter/filters.py에서 「필터 없음」과 제안 필터(속 빈 창 순위형 빼기)만 옮겼다. 함수는 그대로이고 맨 아래 FILTERS 표만 두 줄로 줄였다.

제안 필터가 하는 일: 화소마다 그 둘레의 「고리」(바깥 한 변 G + 2W인 정사각형에서 가운데 G × G를 비운 띠) 안 화소들을 크기 순으로 놓고
q 분위 값 B를 고른다(배경 추정). 출력 P = max(I − B, 0) — 둘레 배경보다 밝은 만큼만 남는다. 설정은 G 29 · W 12 · q 7/8.
검출기에는 [I, P, I](가운데 채널만 필터 출력)로 넣는다."""
from fractions import Fraction
import numpy as np
from numba import njit


def none(I):
    """필터 없음: P = I"""
    return I.copy()


# ---------------- 속 빈 창 (고리) ----------------
@njit(cache=True, inline='always')
def _col_row(img, yy, cH, cC, s):
    """열 히스토그램 전체에 한 줄(yy)을 더하거나(s = 1) 뺀다(s = −1)."""
    for x in range(img.shape[1]):
        v = img[yy, x]; cH[x, v] += s; cC[x, v >> 4] += s


@njit(cache=True, inline='always')
def _add(h, c, xx, lo, n, s):
    """h[k] += s·c[xx, lo + k], k < n"""
    for k in range(n): h[k] += s * c[xx, lo + k]


@njit(cache=True)
def _ring_quantiles(img, G, Wd, qn, qd):
    """고리(바깥 한 변 G+2W, 가운데 G×G 비움) 안 영상 화소의 오름차순 ⌈q·N⌉번째 값 — q마다 (len(qn), H, W) int16, 무효 화소 −1.
    열 히스토그램(바깥 높이 G+2W · 안쪽 높이 G) + 거친 칸 16개 + 고운 칸 게으른 갱신(Perreault–Hébert 꼴)."""
    H, Wi = img.shape
    r = (G - 1) // 2; R = r + Wd
    nfull = (G + 2 * Wd) ** 2 - G * G
    out = np.full((len(qn), H, Wi), -1, np.int16)
    cO = np.zeros((Wi, 256), np.int32); cI = np.zeros((Wi, 256), np.int32)    # 열 히스토그램 (고운 칸)
    oc = np.zeros((Wi, 16), np.int32); ic = np.zeros((Wi, 16), np.int32)      # 열 히스토그램 (거친 칸)
    for yy in range(0, min(H - 1, R) + 1): _col_row(img, yy, cO, oc, 1)
    for yy in range(0, min(H - 1, r) + 1): _col_row(img, yy, cI, ic, 1)
    hc = np.zeros(16, np.int32); last = np.zeros(16, np.int64)
    hf = np.zeros((16, 16), np.int32)                                         # 고운 칸 [거친 칸, 16]
    for y in range(H):
        if y > 0:  # 열 히스토그램을 한 줄 내린다
            if y + R < H: _col_row(img, y + R, cO, oc, 1)
            if y - R - 1 >= 0: _col_row(img, y - R - 1, cO, oc, -1)
            if y + r < H: _col_row(img, y + r, cI, ic, 1)
            if y - r - 1 >= 0: _col_row(img, y - r - 1, cI, ic, -1)
        nO = min(H - 1, y + R) - max(0, y - R) + 1; nI = min(H - 1, y + r) - max(0, y - r) + 1
        hc[:] = 0
        for xx in range(0, min(Wi - 1, R) + 1): _add(hc, oc, xx, 0, 16, 1)
        for xx in range(0, min(Wi - 1, r) + 1): _add(hc, ic, xx, 0, 16, -1)
        last[:] = -1000000
        for x in range(Wi):
            if x > 0:  # 거친 칸 창을 한 칸 민다: 바깥 +들어옴 −나감, 안쪽 −들어옴 +나감
                if x + R < Wi: _add(hc, oc, x + R, 0, 16, 1)
                if x - R - 1 >= 0: _add(hc, oc, x - R - 1, 0, 16, -1)
                if x + r < Wi: _add(hc, ic, x + r, 0, 16, -1)
                if x - r - 1 >= 0: _add(hc, ic, x - r - 1, 0, 16, 1)
            n = nO * (min(Wi - 1, x + R) - max(0, x - R) + 1) - nI * (min(Wi - 1, x + r) - max(0, x - r) + 1)
            if 2 * n < nfull:
                continue
            for iq in range(len(qn)):
                kk = (qn[iq] * n + qd[iq] - 1) // qd[iq]          # ⌈q·N⌉ (정수 연산)
                cum = 0; cb = 0
                while cum + hc[cb] < kk:
                    cum += hc[cb]; cb += 1
                lo = cb * 16; h = hf[cb]                           # 고운 칸 cb를 x에 맞춘다
                if x - last[cb] > 2 * R + 2:                       # 오래됐으면 새로 센다
                    h[:] = 0
                    for xx in range(max(0, x - R), min(Wi - 1, x + R) + 1): _add(h, cO, xx, lo, 16, 1)
                    for xx in range(max(0, x - r), min(Wi - 1, x + r) + 1): _add(h, cI, xx, lo, 16, -1)
                elif last[cb] < x:                                 # 마지막으로 맞춘 곳부터 밀어 온다
                    for xp in range(last[cb] + 1, x + 1):
                        if xp + R < Wi: _add(h, cO, xp + R, lo, 16, 1)
                        if xp - R - 1 >= 0: _add(h, cO, xp - R - 1, lo, 16, -1)
                        if xp + r < Wi: _add(h, cI, xp + r, lo, 16, -1)
                        if xp - r - 1 >= 0: _add(h, cI, xp - r - 1, lo, 16, 1)
                last[cb] = x
                fb = 0
                while cum + h[fb] < kk:
                    cum += h[fb]; fb += 1
                out[iq, y, x] = lo + fb
    return out


def _fr(q):
    f = Fraction(str(q)); return f.numerator, f.denominator


def ring_quantiles(I, G, W, qs):
    """고리 분위값 B_q (q마다), int16, 무효 화소 −1. q는 0.875 · '7/8' 꼴."""
    qn, qd = zip(*[_fr(q) for q in qs])
    return _ring_quantiles(np.ascontiguousarray(I, np.uint8), int(G), int(W), np.array(qn, np.int64), np.array(qd, np.int64))


def hollow_rank(I, G, W, q):
    """제안 필터(속 빈 창 순위형 빼기) P = max(I − B_q, 0), 무효 화소 0. G = 보호 칸 한 변(px, 홀수) · W = 고리 폭(px) · q = 분위."""
    B = ring_quantiles(I, G, W, [q])[0]
    return np.where(B >= 0, np.maximum(I.astype(np.int16) - B, 0), 0).astype(np.uint8)


# 이름 → (함수, 행 버퍼 = 세로로 필요한 줄 수(바깥 한 변))
FILTERS = {
    'none':        (none,        lambda: 0),
    'hollow_rank': (hollow_rank, lambda G, W, q: G + 2 * W),
}


def apply(I, name, params=None):
    return FILTERS[name][0](I, **(params or {}))
