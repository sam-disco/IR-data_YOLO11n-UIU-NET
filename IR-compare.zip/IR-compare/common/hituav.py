"""HIT-UAV 데이터 — 야간 영상 목록 · 로더 · YOLO 라벨 · 입력 꼴([I, I, I] · [I, F, I]) 빌드 · MANIFEST · 배포 분할 목록.
기존 저장소 IR-night-filter(14차 수정4) src/irfilter/data_hituav.py에서 옮겼다. setup_hituav는 안내 문장을 고쳤고, 맨 아래 「배포 분할」 두 함수는 새로 썼고, 나머지는 그대로다(대응표 docs/FILE_MAP.md).

분할 이름이 두 가지 나온다. 헷갈리지 않게 적어 둔다.
  배포 분할(orig)  HIT-UAV가 나눠 준 train · val · test — **이 패키지가 학습 · 평가에 쓰는 분할**(야간 1,390 · 195 · 396장)
  저장 폴더(split)  만든 PNG가 놓이는 폴더 이름 train · val · test — 기존 코드가 촬영 날짜로 나눠 저장하던 자리 그대로다(기준 MANIFEST와 대조하려고 바꾸지 않았다).
                  학습 · 평가에 어떤 영상을 쓰는지는 폴더가 아니라 목록(official_lists)이 정한다.
HIT-UAV v1.2.1 그레이 사본(normal_json, 1채널 8비트 JPEG 640×512). 상자는 축 정렬(normal_json), 화소 x…x+w−1."""
import csv, hashlib, json, os, re, time
import numpy as np
from PIL import Image
from . import filters

SPLIT_SHA = 'baa3b1a807819d8791bcd8ed3fe5fcc8646aab871de8f0cc402a67af93e4bd0c'   # split_night_date_v1.csv (장부 M-023)


DATES = dict(train={'20201217', '20210114', '20210119', '20210120', '20210121'}, val={'20210116'},
             test={'20210115', '20210118', '20210123'})                          # 촬영 날짜 단위 분할


YOLO_CLS = {0: 0, 1: 1, 2: 2, 3: 3}   # Person · Car · Bicycle · OtherVehicle. DontCare(4)는 학습 라벨에서 뺀다(평가 정답에는 남김)


H, W = 512, 640


def sha_file(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def arr_sha(a):
    """화소 배열 해시 (H, W, 3) uint8 — MANIFEST의 pixel_sha256"""
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


# ---------------- 분할 ----------------
def make_split(root, out):
    """야간(파일명 첫 자리 1) 1,981장을 날짜로 나눈 csv를 만들고 해시를 대조한다(regen_split_night_date_v1.py와 같은 결과).
    날짜는 rotate_json 주석의 date — rotate_xml <path>의 날짜와 같은지 확인한다."""
    rec = {}
    for sp in ('train', 'val', 'test'):
        for im in json.load(open(f'{root}/rotate_json/annotations/{sp}.json'))['images']:
            if im['filename'].startswith('1'):
                p = re.search(r'<path>(.*?)</path>', open(f"{root}/rotate_xml/Annotations/{im['filename'][:-4]}.xml").read()).group(1)
                assert p.split('\\')[-2] == im['date'] and im['scenario'] == '1'
                rec[im['filename']] = (sp, im['date'])
    assert len(rec) == 1981
    new = lambda d: next(k for k, v in DATES.items() if d in v)
    s = 'image,new_split,orig_split,date\n' + ''.join(f'{f},{new(d)},{o},{d}\n' for f, (o, d) in sorted(rec.items()))
    open(out, 'w', newline='').write(s)
    check_split(out)


def check_split(path):
    h = sha_file(path)
    assert h == SPLIT_SHA, f'분할 파일 해시 불일치 {h} (기대 {SPLIT_SHA[:8]}…)'


def load_split(root, split_csv, split):
    """반환 {파일명: dict(path, date, orig, folder, boxes=[(cls, x, y, w, h), …])}.
    folder = 촬영 폴더(rotate_xml <path>의 마지막 네 성분: night\\고도\\각도\\날짜) — 부트스트랩 묶음 단위."""
    check_split(split_csv)
    rows = {r['image']: r for r in csv.DictReader(open(split_csv, encoding='utf-8')) if r['new_split'] == split}
    out = {}
    for o in sorted({r['orig_split'] for r in rows.values()}):
        d = json.load(open(os.path.join(root, 'normal_json', 'annotations', f'{o}.json'), encoding='utf-8'))
        id2f = {im['id']: im['filename'] for im in d['images']}
        for im in d['images']:
            f = im['filename']
            if f in rows and rows[f]['orig_split'] == o:
                out[f] = dict(path=os.path.join(root, 'normal_json', o, f), date=rows[f]['date'], orig=o, boxes=[])
        for a in d['annotation']:
            f = id2f[a['image_id']]
            if f in out and out[f]['orig'] == o:
                x, y, w, h = a['bbox']
                out[f]['boxes'].append((int(a['category_id']), int(x), int(y), int(w), int(h)))
    assert set(out) == set(rows), '분할 csv와 주석의 영상 목록 불일치'
    for f, v in out.items():
        xml = open(os.path.join(root, 'rotate_xml', 'Annotations', f[:-4] + '.xml'), encoding='utf-8').read()
        p = re.search(r'<path>(.*?)</path>', xml).group(1)
        v['folder'] = '\\'.join(p.split('\\')[-5:-1])
        assert v['folder'].split('\\')[-1] == v['date']
    return out


def yolo_lines(boxes):
    """YOLO 라벨 txt 내용 (DontCare 뺌, 영상 밖은 자름). 화소 x…x+w−1 → 연속 좌표 [x, x+w)"""
    L = []
    for c, x, y, w, h in boxes:
        if c not in YOLO_CLS:
            continue
        x0, y0, x1, y1 = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
        assert x1 > x0 and y1 > y0
        L.append('%d %.6f %.6f %.6f %.6f' % (YOLO_CLS[c], (x0 + x1) / 2 / W, (y0 + y1) / 2 / H, (x1 - x0) / W, (y1 - y0) / H))
    return ''.join(l + '\n' for l in L)


# ---------------- 입력 꼴 ----------------
def make_input(I, cond, cache=None):
    """cond = dict(filter, params, layout). layout: III = [I, I, I] · FFF = [F, F, F] · IFI = [I, F, I]
    · IF2 = [I, F₁, F₂] (PNG 파일 채널 순서 R, G, B). cache: 같은 필터·설정을 한 영상에서 한 번만 계산."""
    lay = cond.get('layout', 'IFI')
    if lay == 'III':
        return np.stack([I, I, I], -1)
    key = (cond['filter'], json.dumps(cond.get('params') or {}, sort_keys=True))
    if cache is not None and key in cache:
        F = cache[key]
    else:
        F = filters.apply(I, cond['filter'], cond.get('params'))
        assert F.dtype == np.uint8
        if cache is not None:
            cache[key] = F
    if lay == 'IF2':                                       # [I, F₁, F₂] — 두 지도를 내는 필터(n2: [I, P⁺, P⁻])
        assert F.shape == I.shape + (2,)
        return np.stack([I, F[..., 0], F[..., 1]], -1)
    assert F.shape == I.shape
    return {'FFF': lambda: np.stack([F, F, F], -1), 'IFI': lambda: np.stack([I, F, I], -1)}[lay]()


def data_yaml(out, name):
    return (f'# {name}\npath: {os.path.abspath(os.path.join(out, name))}\ntrain: images/train\nval: images/val\n'
            'names:\n  0: Person\n  1: Car\n  2: Bicycle\n  3: OtherVehicle\n')


def _one(job):
    """영상 한 장: 조건마다 입력을 만들고(쓰기 선택) MANIFEST 행을 돌려준다."""
    sp, name, info, conds, out, write = job
    I = np.array(Image.open(info['path']))
    assert I.dtype == np.uint8 and I.shape == (H, W)
    lab = yolo_lines(info['boxes']); lsha = hashlib.sha256(lab.encode()).hexdigest(); stem = name[:-4]
    rows, cache = [], {}
    for cn, cond in conds.items():
        im = make_input(I, cond, cache)
        rows.append((sp, cn, stem, arr_sha(im), lsha))
        if write:
            Image.fromarray(im, 'RGB').save(os.path.join(out, cn, 'images', sp, stem + '.png'), format='PNG')
            open(os.path.join(out, cn, 'labels', sp, stem + '.txt'), 'w', newline='\n').write(lab)
    return rows


def build(root, split_csv, out, conds, splits=('train', 'val'), jobs=1, write=True, limit=0):
    """conds = {이름: dict(filter, params, layout)}. 결과:
      <out>/<이름>/images/<split>/<stem>.png (무손실 8비트 3채널) · labels/<split>/<stem>.txt · data.yaml
      <out>/meta/<split>_gt.json (평가 정답: DontCare 포함 원 정수 상자 · 날짜 · 촬영 폴더)
      <out>/MANIFEST_build_<split>.csv (split, cond, stem, pixel_sha256, label_sha256)
    write=False면 영상을 쓰지 않고 MANIFEST만(대조용). 반환: MANIFEST 행 목록."""
    os.makedirs(os.path.join(out, 'meta'), exist_ok=True)
    allrows = []
    for sp in splits:
        d = load_split(root, split_csv, sp); names = sorted(d)[:limit or None]
        meta = {n: dict(date=d[n]['date'], folder=d[n]['folder'], boxes=d[n]['boxes']) for n in names}
        with open(os.path.join(out, 'meta', f'{sp}_gt.json'), 'w', encoding='utf-8', newline='\n') as f:
            json.dump(meta, f, ensure_ascii=False, indent=0)
        if write:
            for cn in conds:
                for sub in ('images', 'labels'):
                    os.makedirs(os.path.join(out, cn, sub, sp), exist_ok=True)
        jobsl = [(sp, n, d[n], conds, out, write) for n in names]
        t0 = time.time(); rows = []
        if jobs > 1:
            import multiprocessing as mp
            with mp.get_context('spawn').Pool(jobs) as pool:
                for i, r in enumerate(pool.imap(_one, jobsl, chunksize=4)):
                    rows += r
                    if i % 200 == 0: print(sp, i, len(names), '%.0f s' % (time.time() - t0), flush=True)
        else:
            for i, j in enumerate(jobsl):
                rows += _one(j)
                if i % 200 == 0: print(sp, i, len(names), '%.0f s' % (time.time() - t0), flush=True)
        with open(os.path.join(out, f'MANIFEST_build_{sp}.csv'), 'w', newline='\n', encoding='utf-8') as f:
            f.write('split,cond,stem,pixel_sha256,label_sha256\n')
            for r in sorted(rows): f.write(','.join(r) + '\n')
        print(sp, '끝', len(names), '장', '%.0f s' % (time.time() - t0), flush=True)
        allrows += rows
    if write:
        for cn in conds:
            open(os.path.join(out, cn, 'data.yaml'), 'w', newline='\n', encoding='utf-8').write(data_yaml(out, cn))
    return allrows


def read_manifest(paths):
    """{(split, cond, stem): (pixel_sha256, label_sha256)}"""
    m = {}
    for p in paths:
        for r in csv.DictReader(open(p, encoding='utf-8')):
            m[(r['split'], r['cond'], r['stem'])] = (r['pixel_sha256'], r['label_sha256'])
    return m


def compare_manifest(rows, ref):
    """새 행과 기준 MANIFEST(read_manifest 결과)를 대조. 반환 (대조한 행 수, 다른 행, 기준에 없는 행)."""
    n, diff, missing = 0, [], []
    for sp, c, s, ph, lh in rows:
        k = (sp, c, s)
        if k not in ref:
            missing.append(k); continue
        n += 1
        if ref[k] != (ph, lh):
            diff.append(k)
    return n, diff, missing


def verify(out, manifests):
    """빌드 폴더의 PNG·txt를 다시 읽어 MANIFEST와 같은지 본다(사용자 기계에서). 반환 (행 수, 불일치, 파일 없음)."""
    n = bad = miss = 0
    for (sp, c, s), (ph, lh) in read_manifest(manifests).items():
        n += 1
        ip = os.path.join(out, c, 'images', sp, s + '.png'); lp = os.path.join(out, c, 'labels', sp, s + '.txt')
        if not (os.path.exists(ip) and os.path.exists(lp)):
            miss += 1; continue
        a = np.asarray(Image.open(ip))
        if not (a.shape == (H, W, 3) and arr_sha(a) == ph and sha_file(lp) == lh):
            bad += 1
            if bad <= 20: print('불일치', sp, c, s)
    return n, bad, miss


# ---------------- 원본 받기 · 풀기 ----------------
def _download(url, dst, say):
    import urllib.request
    say('내려받기', url)
    req = urllib.request.Request(url, headers={'User-Agent': 'IR-night-filter'})
    with urllib.request.urlopen(req, timeout=120) as r, open(dst + '.part', 'wb') as f:
        n = 0
        for b in iter(lambda: r.read(1 << 22), b''):
            f.write(b); n += len(b)
            if n % (1 << 27) < (1 << 22):
                say(f'  {n / 1e6:.0f} MB')
    os.replace(dst + '.part', dst)


def setup_hituav(cfg, say, split=True):
    """① HIT-UAV v1.2.1 zip(있으면 그대로, 없으면 urls.hituav 차례로 받음) sha256 = 5fed15d2… ② 필요한 폴더만 풀기(normal_json · rotate_json/annotations ·
    rotate_xml/Annotations) → hituav_root.txt ③ 분할 csv를 다시 만들어(make_split) assets의 것과 바이트가 같은지(baa3b1a8…).
    기존 data_hituav.setup_hituav. 고친 곳: 오류 때의 안내 문장(이 패키지의 명령으로) · 푼 폴더 기록이 옛 경로를 가리키면 다시 찾음. 순서 · 확인은 같다."""
    import zipfile
    P = cfg['paths']; z = P['hituav_zip']; d = P['hituav_dir']; t = os.path.join(d, 'hituav_root.txt'); os.makedirs(d, exist_ok=True)
    if os.path.exists(t) and os.path.isdir(os.path.join(open(t, encoding='utf-8').read().strip(), 'normal_json')):
        root = open(t, encoding='utf-8').read().strip(); say('HIT-UAV 폴더 있음:', root)
    else:
        found = [r for r, sub, _ in os.walk(d) if 'normal_json' in sub and 'rotate_json' in sub and 'rotate_xml' in sub]
        if found:                                             # 패키지 폴더를 옮겨 기록의 경로가 달라진 경우
            root = found[0]; open(t, 'w', encoding='utf-8').write(root); say('HIT-UAV 폴더 있음:', root)
        else:
            if not os.path.exists(z):
                last = None
                for u in cfg['urls']['hituav']:
                    try:
                        _download(u, z, say)
                        if sha_file(z) == cfg['hashes']['hituav_zip']:
                            break
                        os.replace(z, z + '.hash_mismatch'); last = f'{u}: sha256 다름'
                    except Exception as x:
                        last = f'{u}: {x!r}'
                if not os.path.exists(z):
                    raise RuntimeError(f'HIT-UAV zip을 받지 못함({last}) — 이미 가진 zip이 있으면 --hituav-zip <경로>로 주거나 {z}에 둔 뒤 다시')
            h = sha_file(z)
            if h != cfg['hashes']['hituav_zip']:
                raise RuntimeError(f'HIT-UAV zip sha256 {h[:8]}… ≠ 5fed15d2… — v1.2.1 zip(814,751,578 B)이 맞는지 본다: {z}')
            say('HIT-UAV zip sha256 일치 — 풀기(필요한 폴더만) …')
            with zipfile.ZipFile(z) as f:
                ms = [m for m in f.namelist() if re.search(r'/(normal_json/|rotate_json/annotations/|rotate_xml/Annotations/)', m)]
                f.extractall(d, ms)
            root = next(os.path.join(r) for r, sub, _ in os.walk(d) if 'normal_json' in sub and 'rotate_xml' in sub)
            open(t, 'w', encoding='utf-8').write(root)
    if not split:
        return dict(root=root, zip_sha256=sha_file(z) if os.path.exists(z) else None)
    regen = os.path.join(d, 'split_regen.csv')
    make_split(root, regen)                                   # 해시가 다르면 여기서 멈춤(check_split)
    if sha_file(regen) != sha_file(P['split_csv']):
        raise RuntimeError('다시 만든 분할 csv가 assets의 것과 다름')
    say('분할 csv 다시 만들기: sha256 baa3b1a8… · assets의 것과 같음')
    return dict(root=root, zip_sha256=sha_file(z) if os.path.exists(z) else None, split_sha256=sha_file(regen))


# ---------------- 배포 분할 (새로 쓴 것 — 목록 · yaml의 꼴은 기존 코드의 것과 같다) ----------------
ORIG_SPLITS = ('train', 'val', 'test')


def official_lists(root, split_csv):
    """배포 분할 {'train' | 'val' | 'test': {파일명: info}} — 야간 1,981장(1,390 · 195 · 396).
    info = dict(path(원본 JPEG), date, orig(배포 분할), folder, boxes, split(PNG가 놓인 저장 폴더))."""
    allv = {}
    for sp in ('train', 'val', 'test'):
        for n, v in load_split(root, split_csv, sp).items():
            allv[n] = dict(v, split=sp)
    return {o: {n: allv[n] for n in sorted(allv) if allv[n]['orig'] == o} for o in ORIG_SPLITS}


def official_data(build, cond, root, split_csv):
    """배포 분할용 YOLO 데이터 yaml(PNG는 다시 만들지 않고 목록만): <build>/<cond>/official/official.yaml · train.txt · val.txt · test.txt.
    yaml의 train = 배포 train(학습) · val = 배포 val(학습 중 검증). 반환 yaml 경로. 목록은 파일명 오름차순."""
    L = official_lists(root, split_csv); fd = os.path.join(build, cond, 'official'); os.makedirs(fd, exist_ok=True)
    png = lambda n, v: os.path.abspath(os.path.join(build, cond, 'images', v['split'], n[:-4] + '.png'))
    for o in ORIG_SPLITS:
        open(os.path.join(fd, f'{o}.txt'), 'w', newline='\n').write(''.join(png(n, L[o][n]) + '\n' for n in sorted(L[o])))
    y = os.path.join(fd, 'official.yaml')
    open(y, 'w', newline='\n', encoding='utf-8').write(
        f'# {cond} official\npath: {os.path.abspath(os.path.join(build, cond))}\ntrain: {os.path.abspath(os.path.join(fd, "train.txt"))}\n'
        f'val: {os.path.abspath(os.path.join(fd, "val.txt"))}\nnames:\n  0: Person\n  1: Car\n  2: Bicycle\n  3: OtherVehicle\n')
    return y
