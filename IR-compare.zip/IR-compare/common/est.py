"""예상 시간 — 시작할 때 추정값을 출력하고, 첫 학습의 1 epoch를 잰 뒤 다시 계산한다. 값은 모두 추정이다(기계마다 다르다)."""
START = {   # 시작할 때 보이는 추정값(잰 값이 아니다)
    'prepare': '데이터 준비(풀기 · 목록 · 제안 필터 적용 · 대조): 몇 분(추정)',
    'filter': 'YOLO11n 학습 2회(원영상 · 제안 필터) + 평가: 서버급 GPU 약 15분 · PC(RTX 4070) 약 30분(추정)',
    'uiunet': 'UIU-Net 학습 4회(원영상 · 제안 필터 × 타원 · 상자) + 평가: 서버급 GPU 약 3시간 · PC(RTX 4070) 약 18시간(추정)',
}
NAME = {'filter': 'YOLO11n', 'uiunet': 'UIU-Net'}


def hm(sec):
    sec = max(float(sec), 0.0)
    return f'{int(sec // 3600)}시간 {int(sec % 3600 // 60)}분' if sec >= 3600 else f'{int(sec // 60)}분 {int(sec % 60)}초'


class Estimate:
    def __init__(self, out=print):
        self.out = out; self.seen = set()

    def start(self, stages, left):
        """stages = 돌릴 단계 · left = {단계: 남은 학습 수}"""
        self.out('예상 시간(추정 — 첫 학습의 1 epoch를 잰 뒤 다시 계산해 알려 준다)')
        for s in stages:
            if s in START:
                self.out(f'  {START[s]} · 남은 학습 {left.get(s, "?")}회')

    def epoch(self, what, epoch, epoch_s, epochs, runs_left):
        """epoch 하나가 끝날 때마다 불린다. 단계마다 처음 한 번(이번 실행에서 처음 잰 epoch)만 다시 계산해 출력한다."""
        if what in self.seen or not epoch_s:
            return
        self.seen.add(what)
        this = epoch_s * max(epochs - epoch, 0); rest = epoch_s * epochs * max(runs_left - 1, 0)
        self.out(f'  [{NAME[what]}] epoch {epoch} = {epoch_s:.0f}초 → 이 학습의 남은 시간 약 {hm(this)} · 남은 학습 {max(runs_left - 1, 0)}회까지 약 {hm(this + rest)}'
                 '(추정 · 평가 시간 제외)')

    def run_done(self, what, run_s, runs_left):
        if runs_left > 0:
            self.out(f'  [{NAME[what]}] 방금 끝난 학습 · 평가 {hm(run_s)} → 남은 학습 {runs_left}회 약 {hm(run_s * runs_left)}(추정)')
