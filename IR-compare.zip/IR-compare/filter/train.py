"""YOLO11n 학습 — 기존 저장소 IR-night-filter(14차 수정4) src/irfilter/train.py의 학습 함수.
「그대로」 구역 밖의 함수는 고친 것이다(무엇을 왜 고쳤는지는 함수 설명과 docs/FILE_MAP.md).
  입력 영상 data/build/<조건>/images · labels · 가중치 results/filter/runs/official_<조건>_s<seed>/weights/last.pt"""
import csv, datetime, json, os, platform, subprocess, sys, time
from common import Stop
from common import hituav as data


WEIGHTS = {'yolo11n.pt': '0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1'}   # github.com/ultralytics/assets 릴리스 v8.3.0


ULTRALYTICS_VERSION = '8.4.200'


PROGRESS = ['logged_at', 'session', 'step', 'cond', 'seed', 'split', 'seconds', 'status', 'last_pt_sha256', 'eval_sha256', 'note']


# ================================================================ 기존 train.py 그대로
def fold_tag(cfg):
    """접기·비율 이름 조각. K3 + 전량은 빈 문자열 — F-2·F-3 실행 이름·데이터와 같게(재사용)."""
    f, r = cfg.get('fold', 'K3'), float(cfg.get('ratio', 1.0))
    return '' if (f == 'K3' and r >= 1) else f'_{f}' + ('' if r >= 1 else f'_D{int(round(r * 100))}')


def run_name(cfg, cond, seed):
    return f"{cfg.get('tag') or ''}{cond}{fold_tag(cfg)}_s{seed}"


def log(cfg, **kw):
    p = cfg['P']['progress']; os.makedirs(os.path.dirname(p), exist_ok=True); new = not os.path.exists(p)
    with open(p, 'a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, PROGRESS)
        if new: w.writeheader()
        w.writerow({k: kw.get(k, '') for k in PROGRESS} | {'logged_at': datetime.datetime.now().isoformat(timespec='seconds'),
                                                         'session': cfg['_session']})


def env_record(cfg):
    """실행 환경 기록 → work/logs/env_<세션>.json"""
    e = dict(python=sys.version, os=platform.platform(), cfg_sha256=cfg['_sha'])
    for m in ('torch', 'ultralytics', 'numpy', 'cv2', 'PIL', 'numba', 'scipy'):
        try:
            e[m] = __import__(m).__version__
        except Exception as x:
            e[m] = f'없음 ({x})'
    try:
        import torch
        e.update(cuda=torch.version.cuda, gpu=[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())])
        e['nvidia_smi'] = subprocess.run(['nvidia-smi', '--query-gpu=name,driver_version,memory.total,memory.used', '--format=csv'],
                                         capture_output=True, text=True, timeout=20).stdout
    except Exception as x:
        e['gpu_note'] = str(x)
    os.makedirs(cfg['P']['logs'], exist_ok=True)
    json.dump(e, open(os.path.join(cfg['P']['logs'], f"env_{cfg['_session']}.json"), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    return e


def train_args(cfg, cond, seed):
    """Ultralytics model.train에 넘기는 인자 dict (F-1 train.py와 같은 키·값).
    ratio < 1이면 같은 걸음 수: epochs · warmup_epochs · close_mosaic를 ÷ ratio (PREREG_N §3 S1-b)."""
    a = dict(data=data_yaml_for(cfg, cond, seed), epochs=cfg['epochs'], seed=seed, device=cfg['device'],
             workers=cfg['workers'], project=cfg['P']['runs'], name=run_name(cfg, cond, seed), exist_ok=False, pretrained=True,
             **cfg['hyp'])
    r = float(cfg.get('ratio', 1.0))
    if r < 1:
        a['epochs'] = int(round(cfg['epochs'] / r))
        a['warmup_epochs'] = cfg['hyp']['warmup_epochs'] / r
        a['close_mosaic'] = int(round(cfg['hyp']['close_mosaic'] / r))
    return a


def train_state(cfg, cond, seed):
    """'done'(run_record와 last.pt 해시 맞음) · 'todo'(폴더 없음) · 'partial'(그 밖 — 멈춘다)"""
    rd = os.path.join(cfg['P']['runs'], run_name(cfg, cond, seed)); rr = os.path.join(rd, 'run_record.json')
    if not os.path.exists(rd):
        return 'todo', None
    lp = os.path.join(rd, 'weights', 'last.pt')
    if os.path.exists(rr) and os.path.exists(lp):
        h = data.sha_file(lp)
        if json.load(open(rr, encoding='utf-8')).get('last_pt_sha256') == h:
            return 'done', h
    return 'partial', None


# ================================================================ 고친 함수
def data_yaml_for(cfg, cond, seed):
    """학습 data.yaml — 배포 분할(train으로 학습 · val로 학습 중 검증). 기존 train.data_yaml_for. 고친 곳: 날짜 분할 · 접기 대신 배포 분할 목록을 쓴다."""
    return data.official_data(cfg['P']['build'], cond, cfg['data']['root'], cfg['data']['split_csv'])


def preflight(cfg, out=print):
    """학습 · 평가 전 준비 확인. 기존 train.preflight. 고친 곳: ① assert 대신 안내 문장을 붙인 멈춤 ② ultralytics 판이 고정판과 다르면 멈추지 않고
    알리기만 한다(보고서에 판이 적힌다) ③ 해시 표에 yolo11n.pt만 둔다. albumentations가 있으면 학습 증강에 ToGray · CLAHE가 끼어 채널이 섞이므로 그대로 막는다."""
    import importlib.util, ultralytics
    if ultralytics.__version__ != ULTRALYTICS_VERSION:
        out(f'주의: ultralytics {ultralytics.__version__} — 기존 실험에 쓴 판은 {ULTRALYTICS_VERSION}이다. 판이 다르면 값이 조금 달라질 수 있다(environment.yml로 맞춘다)')
    if importlib.util.find_spec('albumentations') is not None:
        raise Stop('준비가 덜 됐다: albumentations가 설치되어 있다 → pip uninstall -y albumentations 뒤 같은 명령을 다시 실행한다')
    bn = os.path.basename(cfg['model'])
    if not os.path.exists(cfg['model']):
        raise Stop(f"준비가 덜 됐다: 가중치 없음 {cfg['model']}")
    if data.sha_file(cfg['model']) != WEIGHTS[bn]:
        raise Stop(f"준비가 덜 됐다: {bn} sha256이 고정 값({WEIGHTS[bn][:8]}…)과 다르다 → {cfg['model']}을 지우고 같은 명령을 다시 실행한다(다시 받는다)")


def train_one(cfg, cond, seed, callbacks=None):
    """학습 한 번 → runs/<이름>/weights/last.pt · run_record.json. 기존 train.train_one. 고친 곳: callbacks 인자 하나
    ({이벤트 이름: 함수} — 첫 epoch 시간 재기 · 손실 NaN/Inf 멈춤을 거는 데 쓴다). 학습 인자 · 기록 내용은 그대로다."""
    import torch
    from ultralytics import YOLO
    name = run_name(cfg, cond, seed); args = train_args(cfg, cond, seed)
    rec = dict(cond=cond, seed=seed, cfg_sha256=cfg['_sha'], weights=cfg['model'], weights_sha256=data.sha_file(cfg['model']),
               data_yaml_sha256=data.sha_file(args['data']), condition=cfg['conditions'][cond], train_args=args, epoch_log=[])
    model = YOLO(cfg['model'])
    model.add_callback('on_fit_epoch_end', lambda tr: rec['epoch_log'].append(dict(
        epoch=tr.epoch + 1, epoch_time_s=tr.epoch_time,
        max_mem_reserved_GB=torch.cuda.max_memory_reserved() / 1e9 if torch.cuda.is_available() else None)))
    for ev, fn in (callbacks or {}).items():
        model.add_callback(ev, fn)
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    model.train(**args)
    rec['wall_time_s'] = time.time() - t0
    if torch.cuda.is_available():
        rec['max_mem_allocated_GB'] = torch.cuda.max_memory_allocated() / 1e9
        rec['max_mem_reserved_GB'] = torch.cuda.max_memory_reserved() / 1e9
    rd = os.path.join(cfg['P']['runs'], name)
    rec['last_pt_sha256'] = data.sha_file(os.path.join(rd, 'weights', 'last.pt'))
    json.dump(rec, open(os.path.join(rd, 'run_record.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    return rec
