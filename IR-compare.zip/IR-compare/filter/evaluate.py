"""YOLO11n 평가 — 기존 저장소 IR-night-filter(14차 수정4) src/irfilter/evaluate.py의 eval_one · eval_done.
last.pt로 영상마다 예측 → 검출 원자료 + 요약(common.metrics.summarize) → evals/<이름>_<분할>.json.gz. 불러오기 한 줄씩만 고쳤다(docs/FILE_MAP.md)."""
import json, os
from common import hituav as data
from .train import run_name


def eval_one(cfg, cond, seed, split, gt, src, model_path=None, tag=''):
    """last.pt로 예측 → 검출 원자료 + 요약(metrics.summarize) → evals/<이름>_<split>.json.gz
    기존 evaluate.eval_one. 고친 곳: metrics를 common에서 불러오는 한 줄. 예측 · 채점 · 파일 꼴은 그대로다."""
    import gzip
    import numpy as np
    from PIL import Image
    from ultralytics import YOLO
    from common import metrics
    name = run_name(cfg, cond, seed); lp = model_path or os.path.join(cfg['P']['runs'], name, 'weights', 'last.pt')
    stems = sorted(k[:-4] for k in gt); model = YOLO(lp, task='detect'); preds = {}
    ecfg = dict(cfg['eval'], **({'rect': False} if lp.endswith('.onnx') else {}))   # 고정 크기 ONNX는 정사각 640
    for s in stems:
        b = model.predict(os.path.join(cfg['P']['build'], cond, 'images', src[s + '.jpg'].get('split', split), s + '.png'),
                          device=cfg['device'], verbose=False, **ecfg)[0].boxes
        preds[s] = np.c_[b.xyxy.cpu().numpy(), b.conf.cpu().numpy(), b.cls.cpu().numpy()].tolist()
    orig = lambda s: np.asarray(Image.open(src[s + '.jpg']['path']))           # 「선 구조 위」는 원영상 I로 판정
    res = dict(cond=f"{cfg.get('tag') or ''}{cond}", seed=seed, split=split, weights_sha256=data.sha_file(lp), eval_cfg=ecfg,
               fold=cfg.get('fold', 'K3'), ratio=float(cfg.get('ratio', 1.0)), model_kind=tag or 'pt',
               summary=metrics.summarize(stems, preds, gt, orig), preds=preds)
    os.makedirs(cfg['P']['evals'], exist_ok=True)
    p = os.path.join(cfg['P']['evals'], f'{name}{tag}_{split}.json.gz')
    with gzip.open(p + '.part', 'wt', encoding='utf-8') as f:
        json.dump(res, f)
    os.replace(p + '.part', p)                                                  # 끊겨도 반쯤 쓴 파일이 남지 않게
    return p


def eval_done(cfg, cond, seed, split, h, tag=''):
    """이 가중치(sha256 h)로 만든 평가 파일이 이미 있는가. 기존 evaluate.eval_done. 고친 곳: metrics를 common에서 불러온다."""
    from common import metrics
    p = os.path.join(cfg['P']['evals'], f'{run_name(cfg, cond, seed)}{tag}_{split}.json.gz')
    try:
        return os.path.exists(p) and metrics.read_eval(p)['weights_sha256'] == h
    except Exception:
        return False
