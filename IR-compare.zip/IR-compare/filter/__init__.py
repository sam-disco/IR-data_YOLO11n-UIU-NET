"""YOLO11n — 입력 둘(원영상 [I, I, I] · 제안 필터 [I, P, I]) × seed 0 = 학습 2회. 배포 분할 train으로 학습하고 test · val로 평가한다."""
