"""YOLO11n 실행 — yolo11n.pt 받기 → 입력 둘(원영상 · 제안 필터) × seed 0 학습 2회 → 배포 분할 test · val에서 평가.
기존 저장소 IR-night-filter(14차 수정4) src/irfilter/train.py의 cmd_loop · v2cfg를 이 패키지 꼴로 고친 것이다(고친 곳은 함수 설명과 docs/FILE_MAP.md).
학습 인자 · 평가 설정은 기존과 같다. 끝난 학습 · 평가는 건너뛴다. 끊긴 학습은 폴더를 옮겨 두고(지우지 않음) 그 학습만 처음부터 다시 한다."""
import datetime, os, time
from common import ROOT, Stop
from common import hituav as DATA
from common.hituav import _download
from . import train as T, evaluate as E

TAG = 'official'                      # 실행 이름 머리: official_<조건>_s<seed>


def make_cfg(Q, root, device, session):
    """학습 · 평가 함수가 읽는 cfg dict. 기존 train.v2cfg. 고친 곳: 경로(입력 영상 data/build · 가중치 · 평가 · 기록 = results/filter) · 조건 목록(Baseline · 제안 필터) ·
    실행 이름 머리(official_) · HIT-UAV 폴더(root)를 인자로 받는다. 학습 비결(hyp) · epochs · 평가 설정은 그대로."""
    res = os.path.join(Q['_res'], 'filter')
    c = dict(data=dict(root=root, split_csv=Q['paths']['split_csv']), conditions=Q['conditions'], run=list(Q['filter']['conds']), fold='K3', ratio=1.0,
             model=os.path.join(ROOT, 'weights', Q['model']), tag=f'{TAG}_', seeds=list(Q['filter']['seeds']),
             epochs=Q['epochs'], device=str(device), workers=Q['workers'], hyp=Q['hyp'], eval=Q['eval'])      # fold K3 · ratio 1 = 실행 이름에 접기 꼬리를 붙이지 않음
    c['P'] = dict(work=res, build=Q['paths']['build'], runs=os.path.join(res, 'runs'), evals=os.path.join(res, 'evals'),
                  logs=os.path.join(res, 'logs'), progress=os.path.join(res, 'logs', 'progress.csv'))
    c['_sha'] = Q['_sha']; c['_session'] = session; c['_training'] = TAG
    return c


def ensure_weights(Q, out):
    """yolo11n.pt를 weights/에 받고 sha256을 본다(기존 data_hituav.setup_weights와 같은 주소 · 같은 해시)"""
    p = os.path.join(ROOT, 'weights', Q['model']); os.makedirs(os.path.dirname(p), exist_ok=True)
    if not os.path.exists(p):
        try:
            _download(Q['urls']['yolo'].format(name=Q['model']), p, out)
        except Exception as x:
            raise Stop(f"준비가 덜 됐다: {Q['model']}을 받지 못했다({x!r}) — 인터넷 연결을 본 뒤 같은 명령을 다시 실행한다. "
                       f"인터넷이 안 되는 기계면 다른 기계에서 {Q['urls']['yolo'].format(name=Q['model'])}을 받아 {p}에 둔다")
    return p


def jobs(Q):
    """[(조건, seed)]"""
    return [(c, s) for s in Q['filter']['seeds'] for c in Q['filter']['conds']]


def todo(Q, root, device='0'):
    """아직 끝나지 않은 학습 수"""
    cfg = make_cfg(Q, root, device, '')
    return sum(T.train_state(cfg, c, s)[0] != 'done' for c, s in jobs(Q))


def set_aside(rd, out):
    """반쯤 남은 학습 폴더를 지우지 않고 이름을 바꿔 둔다 → 그 학습은 처음부터 다시 한다"""
    dst = f"{rd}__partial_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.rename(rd, dst); out(f'  반쯤 남은 학습 폴더를 옮겨 둠(지우지 않음): {dst}')


def finite(x):
    """학습 손실 값(텐서 · 숫자 · 그것들의 dict/목록)이 모두 유한한가. 읽지 못하는 꼴이면 True(막지 않음)"""
    import torch
    if x is None:
        return True
    if isinstance(x, dict):
        return all(finite(v) for v in x.values())
    if isinstance(x, (list, tuple)):
        return all(finite(v) for v in x)
    try:
        return bool(torch.isfinite(torch.as_tensor(x, dtype=torch.float64)).all())
    except Exception:
        return True


def gt_of(d):
    """목록 정보 → 채점 정답 {파일명: dict(date, folder, boxes)}"""
    return {n: dict(date=v['date'], folder=v['folder'], boxes=v['boxes']) for n, v in d.items()}


def run(Q, root, out, device, est=None):
    """기존 train.cmd_loop. 고친 곳: ① 반쯤 남은 학습은 멈추지 않고 폴더를 옮겨 둔 뒤 처음부터 다시 한다 ② 평가 집합 = 배포 분할 test · val
    ③ 첫 epoch 시간으로 남은 시간을 다시 계산한다 ④ 손실이 NaN/Inf면 멈춘다."""
    session = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    cfg = make_cfg(Q, root, device, session); L = DATA.official_lists(root, cfg['data']['split_csv'])
    ensure_weights(Q, out); T.preflight(cfg, out); T.env_record(cfg)
    for cond, s in jobs(Q):
        name = T.run_name(cfg, cond, s); st, h = T.train_state(cfg, cond, s); t0 = time.time()
        if st == 'partial':
            set_aside(os.path.join(cfg['P']['runs'], name), out); st = 'todo'
        if st == 'todo':
            out(f'---- YOLO11n 학습 {name} (배포 train {len(L["train"])}장 · 학습 중 검증 val {len(L["val"])}장)')

            def on_fit(tr):
                if est:
                    est.epoch('filter', tr.epoch + 1, tr.epoch_time, cfg['epochs'], todo(Q, root, device))

            def on_train(tr, name=name):
                if not (finite(getattr(tr, 'loss', None)) and finite(getattr(tr, 'tloss', None))):
                    raise Stop(f'손실 NaN/Inf — 멈춤: YOLO11n {name} epoch {tr.epoch + 1}')
            try:
                rec = T.train_one(cfg, cond, s, {'on_train_epoch_end': on_train, 'on_fit_epoch_end': on_fit}); h = rec['last_pt_sha256']
                T.log(cfg, step='train', cond=cond, seed=s, seconds='%.0f' % (time.time() - t0), status='ok', last_pt_sha256=h)
            except Exception as x:
                T.log(cfg, step='train', cond=cond, seed=s, seconds='%.0f' % (time.time() - t0), status='fail', note=repr(x)[:300]); raise
        for sp in Q['split']['eval']:
            if E.eval_done(cfg, cond, s, sp, h):
                continue
            out(f'---- YOLO11n 평가 {name} · 배포 {sp} {len(L[sp])}장'); t1 = time.time()
            try:
                p = E.eval_one(cfg, cond, s, sp, gt_of(L[sp]), L[sp])
                T.log(cfg, step='eval', cond=cond, seed=s, split=sp, seconds='%.0f' % (time.time() - t1), status='ok', last_pt_sha256=h, eval_sha256=DATA.sha_file(p))
            except Exception as x:
                T.log(cfg, step='eval', cond=cond, seed=s, split=sp, seconds='%.0f' % (time.time() - t1), status='fail', note=repr(x)[:300]); raise
        if est and st == 'todo':
            est.run_done('filter', time.time() - t0, todo(Q, root, device))
    out('YOLO11n 끝')
