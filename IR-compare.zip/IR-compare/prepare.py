"""데이터 준비 — HIT-UAV 원본 zip 하나에서 학습 · 평가에 쓰는 것을 모두 만든다. 단계마다 맨 먼저 불린다(이미 만들어졌으면 대조만 한다).

  ① zip sha256 확인 → 필요한 폴더만 풀기 → 야간 영상 목록 csv(영상마다 배포 분할 · 촬영 날짜)를 다시 만들어 assets의 것과 같은지 확인
  ② 입력 영상 만들기: 원영상 [I, I, I](원영상을 세 채널에) · 제안 필터 [I, P, I](가운데 채널 = 필터 출력) — 야간 1,981장씩, 무손실 PNG + YOLO 라벨
  ③ 만든 영상을 다시 읽어 MANIFEST(화소 · 라벨 sha256)와 대조. 그중 기준 MANIFEST가 있는 1,593장 × 2는 기준(기존 실험의 입력 영상)과도 영상마다 대조 — 한 장이라도 다르면 멈춘다
  ④ 배포 분할 train · val · test의 영상 수 · 정답 수가 정해진 값과 같은지 확인

①은 기존 data_hituav.setup_hituav, ②는 data_hituav.build, ③은 data_hituav.verify · compare_manifest다.
PNG가 놓이는 폴더 이름(train · val · test)은 기존 코드의 저장 자리 그대로이고 배포 분할과 다르다 — 학습 · 평가에 쓰는 영상은 목록(common.hituav.official_lists)이 정한다.
UIU-Net의 정답 마스크는 여기서 만들지 않는다 — 학습 중에 라벨에서 그린다(uiunet/u_data.py draw_mask)."""
import datetime, hashlib, os
from common import Stop, sha_file, wjson
from common import hituav as D


def conds(cfg):
    return {c: cfg['conditions'][c] for c in cfg['filter']['conds']}


def reference(cfg):
    """기준 MANIFEST {(split, cond, stem): (pixel_sha256, label_sha256)} — assets의 두 파일(파일 sha256 = 설정의 값)"""
    from common import ROOT
    ps = []
    for sp in ('train', 'val'):
        p = os.path.join(ROOT, 'assets', f'MANIFEST_ref_{sp}.csv')
        if not os.path.exists(p) or sha_file(p) != cfg['hashes'][f'manifest_ref_{sp}']:
            raise Stop(f'데이터 MANIFEST 해시 불일치 — 기준 파일 assets/MANIFEST_ref_{sp}.csv가 없거나 바뀌었다. 패키지 zip을 다시 푼다')
        ps.append(p)
    return D.read_manifest(ps)


FOLDERS = ('train', 'val', 'test')        # PNG 저장 폴더(기존 코드의 자리)


def manifests(B):
    return [os.path.join(B, f'MANIFEST_build_{sp}.csv') for sp in FOLDERS]


def against_ref(have, ref):
    """MANIFEST 행 have를 기준 ref와 견준다 → (기준이 있는 행 중 다른 수, 기준이 없는 행 수). 기준 행이 have에 없으면 다른 것으로 센다"""
    d = sum(1 for k in ref if have.get(k) != ref[k])
    return d, sum(1 for k in have if k not in ref)


def check_built(cfg, ref, out):
    """만들어 둔 입력 영상이 온전한가: 기준이 있는 행 = 기준(전량) · 전체 행 수 = 야간 영상 × 조건 · PNG와 라벨을 다시 읽어 MANIFEST와 같은가(전량).
    반환 (같음, 사유, 기준이 없는 행 수)"""
    B = cfg['paths']['build']; want = sum(cfg['split']['counts'][o][0] for o in D.ORIG_SPLITS) * len(conds(cfg))
    if not all(os.path.exists(p) for p in manifests(B)):
        return False, 'MANIFEST 없음(만들다 끊긴 폴더)', 0
    have = D.read_manifest(manifests(B)); d, extra = against_ref(have, ref)
    if d:
        return False, f'MANIFEST가 기준과 {d}행 다르다', extra
    if len(have) != want:
        return False, f'MANIFEST {len(have)}행 — {want}행이어야 한다', extra
    n, bad, miss = D.verify(B, manifests(B))
    if bad or miss:
        return False, f'영상 · 라벨 파일이 MANIFEST와 다르다(다름 {bad} · 없음 {miss} / {n})', extra
    return True, f'{n}행', extra


def check_official(cfg, root, out):
    """배포 분할마다 [영상, Person, Car, Bicycle] 수가 설정의 값과 같은가. 반환 {분할: dict(counts, list_sha256)}"""
    cnt = lambda d, c: sum(b[0] == c for v in d.values() for b in v['boxes']); rec = {}
    L = D.official_lists(root, cfg['paths']['split_csv'])
    for o in D.ORIG_SPLITS:
        got = [len(L[o]), cnt(L[o], 0), cnt(L[o], 1), cnt(L[o], 2)]; h = hashlib.sha256(''.join(sorted(L[o])).encode()).hexdigest()
        if got != list(cfg['split']['counts'][o]):
            raise Stop(f'데이터 MANIFEST 해시 불일치 — 배포 분할 {o}의 영상 수 · 정답 수 {got}가 정해진 값({cfg["split"]["counts"][o]})과 다르다')
        rec[o] = dict(counts=got, list_sha256=h)
        out(f'  배포 {o}: {got[0]}장 · Person {got[1]} · Car {got[2]} · Bicycle {got[3]} · 목록 {h[:12]}')
    return rec


def ensure(cfg, out):
    """데이터를 쓸 수 있게 한다(없으면 만들고, 있으면 대조). 반환 dict(root, rows, built, official, …). 기준과 다르면 멈춘다."""
    B = cfg['paths']['build']; ref = reference(cfg)
    try:
        hit = D.setup_hituav(cfg, out)
    except (RuntimeError, AssertionError) as x:
        raise Stop(f'HIT-UAV 원본을 준비하지 못했다: {x}')
    root = hit['root']; built = False; nimg = sum(cfg['split']['counts'][o][0] for o in D.ORIG_SPLITS)
    if os.path.isdir(B) and os.listdir(B):
        ok, why, extra = check_built(cfg, ref, out)
        if not ok:
            dst = f"{B}__partial_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.rename(B, dst); out(f'입력 영상 폴더가 완성되지 않았거나 기준과 다르다({why}) → 옮겨 둠(지우지 않음): {dst} · 다시 만든다')
    if not (os.path.isdir(B) and os.listdir(B)):
        out(f'입력 영상 만들기: 원영상 [I, I, I] · 제안 필터 [I, P, I] × 야간 {nimg:,}장 → {B}')
        rows = D.build(root, cfg['paths']['split_csv'], B, conds(cfg), FOLDERS, int(cfg.get('jobs', 1)), write=True)
        n, diff, noref = D.compare_manifest(rows, ref); built = True          # n = 기준과 대조한 행 · noref = 기준이 없는 행
        if n != len(ref) or diff or len(rows) != nimg * len(conds(cfg)):
            raise Stop(f'데이터 MANIFEST 해시 불일치 — 만든 입력 영상이 기준과 다르다: 대조 {n}/{len(ref)}행 · 다름 {len(diff)}(예 {diff[:3]}) · 만든 행 {len(rows)}/{nimg * len(conds(cfg))}. '
                       'environment.yml의 판(Pillow · numpy · numba)으로 설치했는지 본다. 설정은 바꾸지 않는다')
        ok, why, extra = check_built(cfg, ref, out)
        if not ok:
            raise Stop(f'데이터 MANIFEST 해시 불일치 — 만든 영상을 다시 읽으니 다르다: {why}')
    out(f'입력 영상: {len(ref) + extra}행(야간 {nimg:,}장 × 조건 2)을 다시 읽어 MANIFEST와 같음 · 그중 기준 MANIFEST가 있는 {len(ref)}행은 기준과 모두 같음'
        f'(나머지 {extra}행은 기준이 없다 — 같은 코드로 만든 것)')
    off = check_official(cfg, root, out)
    rec = dict(root=root, rows=len(ref) + extra, rows_ref=len(ref), rows_noref=extra, built=built, official=off, zip_sha256=hit.get('zip_sha256'),
               split_sha256=hit.get('split_sha256'), manifest_ref={sp: cfg['hashes'][f'manifest_ref_{sp}'] for sp in ('train', 'val')})
    wjson(os.path.join(cfg['_res'], 'logs', 'DATA_CHECK.json'), rec)
    return rec
