"""지침 2장 날짜 배정으로 split_night_date_v1.csv를 다시 만든다 (M-023 sha256과 일치해야 함)
형식: 머리줄 image,new_split,orig_split,date · 파일명 오름차순 · LF · 마지막 줄 끝 LF
날짜: rotate_json annotations의 date (rotate_xml <path>와 대조)"""
import json, re, sys, hashlib
ROOT, OUT = sys.argv[1], sys.argv[2]
TR = {'20201217','20210114','20210119','20210120','20210121'}; VA = {'20210116'}; TE = {'20210115','20210118','20210123'}
rec = {}
for sp in ['train','val','test']:
    for im in json.load(open(f'{ROOT}/rotate_json/annotations/{sp}.json'))['images']:
        if im['filename'].startswith('1'):
            p = re.search(r'<path>(.*?)</path>', open(f"{ROOT}/rotate_xml/Annotations/{im['filename'][:-4]}.xml").read()).group(1)
            assert p.split('\\')[-2] == im['date'] and im['scenario'] == '1'
            rec[im['filename']] = (sp, im['date'])
assert len(rec) == 1981 and set(d for _, d in rec.values()) == TR | VA | TE
ns = lambda d: 'train' if d in TR else 'val' if d in VA else 'test'
s = 'image,new_split,orig_split,date\n' + ''.join(f'{f},{ns(d)},{o},{d}\n' for f, (o, d) in sorted(rec.items()))
open(OUT, 'w', newline='').write(s)
h = hashlib.sha256(s.encode()).hexdigest(); print(h)
assert h == 'baa3b1a807819d8791bcd8ed3fe5fcc8646aab871de8f0cc402a67af93e4bd0c'
