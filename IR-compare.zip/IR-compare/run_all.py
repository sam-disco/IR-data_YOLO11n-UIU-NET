"""IR-compare — HIT-UAV 야간 영상(배포 분할)에서 네 모형의 사람 검출 성능(Person AP50)을 한 줄로 끝까지 잰다.
  YOLO11n · YOLO11n + 제안 필터 · UIU-Net · UIU-Net + 제안 필터   (UIU-Net은 정답 마스크를 타원 · 상자 두 방식으로 — 학습 모두 6회)

  python run_all.py                              HIT-UAV v1.2.1 zip을 받아서 시작
  python run_all.py --hituav-zip <zip 경로>       이미 가진 zip을 씀(sha256 확인)

차례: prepare(원본 풀기 → 야간 영상 목록 → 제안 필터 적용 → 대조) → filter(YOLO11n 2회) → uiunet(UIU-Net 4회) → report(results/REPORT.md).
학습은 배포 train(야간 1,390장), 평가는 배포 test(396장)와 val(195장)이다.
끝난 학습 · 평가는 건너뛴다. 끊기면 같은 명령을 다시 실행한다(UIU-Net은 끊긴 epoch부터, YOLO11n은 끊긴 학습만 처음부터).
단계는 하나씩 따로 띄운 프로세스에서 돈다(--only를 붙여 자기를 다시 부른다) — 앞 단계가 쓰던 GPU 메모리 · 설정이 뒤 단계에 남지 않게 하려는 것이다.

옵션: --device 0(GPU 번호) · --only prepare|filter|uiunet|report(한 단계만 — 데이터 준비 · 대조는 어느 단계든 먼저 한다)
멈추는 경우는 「!! 멈춤:」으로 출력하고 종료 코드 2: 데이터 MANIFEST 해시 불일치 · 손실 NaN/Inf · GPU 없음. (경로 · 설치 준비가 덜 된 경우도 안내하고 끝낸다)
CPU 학습은 막혀 있다."""
import argparse, datetime, os, platform, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
STAGES = ['prepare', 'filter', 'uiunet', 'report']
GPU_STAGES = {'filter', 'uiunet'}


def load_config(path):
    """configs/default.yaml → dict. 상대 경로는 패키지 폴더 기준으로 바꾼다. Q['_sha'] = 설정 파일 sha256"""
    import yaml
    from common import ROOT, sha_file
    with open(path, encoding='utf-8') as f:
        Q = yaml.safe_load(f)
    Q['paths'] = {k: (v if os.path.isabs(str(v)) else os.path.normpath(os.path.join(ROOT, v))) for k, v in Q['paths'].items()}
    Q['_path'] = path; Q['_sha'] = sha_file(path)
    return Q


def require_gpu(device):
    """GPU가 없으면 멈춘다. CPU 학습은 막는다. 반환 GPU 이름"""
    from common import Stop
    d = str(device).strip()
    if d.lower() == 'cpu':
        raise Stop('GPU 없음 — CPU 학습은 막혀 있다(YOLO11n 2회 · UIU-Net 4회는 CPU로 여러 날이 걸린다). GPU가 있는 기계에서 --device <GPU 번호>로 실행한다. '
                   '이미 끝난 결과만 보려면 --only report')
    if not d.isdigit():
        raise Stop(f'--device {device} — GPU 번호 하나만 쓴다(예: --device 0)')
    try:
        import torch
    except ImportError as x:
        raise Stop(f'준비가 덜 됐다: torch를 불러오지 못했다({x}) → README.md 2절의 설치를 한다')
    if not torch.cuda.is_available():
        raise Stop(f'GPU 없음 — torch {torch.__version__}가 GPU를 찾지 못했다. torch가 CUDA판인지 확인한다(README.md 2절의 설치 줄). '
                   'CPU 학습은 막혀 있다. 이미 끝난 결과만 보려면 --only report')
    if int(d) >= torch.cuda.device_count():
        raise Stop(f'GPU 없음 — --device {d}: 이 기계의 GPU는 {torch.cuda.device_count()}개다(번호 0부터)')
    return torch.cuda.get_device_name(int(d))


def env_now(gpu=None):
    e = dict(at=datetime.datetime.now().isoformat(timespec='seconds'), python=platform.python_version(), os=platform.platform(), gpu=gpu)
    for m in ('torch', 'ultralytics', 'numpy', 'cv2', 'PIL', 'scipy', 'numba', 'yaml'):
        try:
            e[m] = __import__(m).__version__
        except Exception as x:
            e[m] = f'없음({type(x).__name__})'
    try:
        import torch
        e['cuda'] = torch.version.cuda
    except Exception:
        e['cuda'] = None
    return e


def run_stages(a, out):
    """--only가 없을 때: 네 단계를 차례로, 단계마다 새 프로세스로 돌린다. 한 단계가 0이 아닌 코드로 끝나면 뒤 단계를 돌리지 않고 그 코드를 돌려준다."""
    from common.est import START
    out(f'==== IR-compare · 단계 {" → ".join(STAGES)}')
    out('예상 시간(추정 — 단계마다 첫 학습의 1 epoch를 잰 뒤 다시 계산해 알려 준다)')
    for s in STAGES:
        if s in START:
            out(f'  {START[s]}')
    t0 = time.time()
    try:
        for st in STAGES:
            cmd = [sys.executable, os.path.abspath(__file__), '--only', st] + (['--hituav-zip', os.path.abspath(a.hituav_zip)] if a.hituav_zip else []) + \
                (['--device', str(a.device)] if a.device is not None else [])
            rc = subprocess.call(cmd)
            if rc != 0:
                out(f'==== 단계 {st}가 끝나지 않았다(종료 코드 {rc}) — 뒤 단계는 돌리지 않는다. 위의 안내대로 한 뒤 같은 명령을 다시 실행하면 이어 간다')
                return rc
    except KeyboardInterrupt:
        out('!! 사용자가 끊음 — 같은 명령을 다시 실행하면 이어 간다'); return 130
    out(f'==== 네 단계 모두 끝 · 이번 실행 {time.time() - t0:.0f}초 · 보고서 {os.path.join(HERE, "results", "REPORT.md")}')
    return 0


def main(argv=None):
    try:
        sys.stdout.reconfigure(errors='replace')
    except Exception:
        pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--hituav-zip', default=None, help='이미 받은 HIT-UAV v1.2.1 zip 경로(없으면 data/hituav/에 받는다)')
    ap.add_argument('--device', default=None, help='GPU 번호(기본 0)')
    ap.add_argument('--only', default=None, choices=STAGES, help='한 단계만: prepare · filter · uiunet · report')
    a = ap.parse_args(argv)
    from common import ROOT, Stop, Log, wjson, rjson
    from common.paths import check_paths
    from common.est import Estimate
    res = os.path.join(ROOT, 'results')
    try:
        check_paths(**{'패키지 폴더': ROOT})
    except Stop as e:
        print(f'!! 멈춤: {e}', flush=True); return 2
    out = Log(os.path.join(res, 'logs', 'run_all.log'))
    if a.only is None:
        return run_stages(a, out)
    st = a.only
    try:
        Q = load_config(os.path.join(ROOT, 'configs', 'default.yaml'))
        if a.hituav_zip:
            Q['paths']['hituav_zip'] = os.path.abspath(a.hituav_zip)
        device = a.device if a.device is not None else Q['device']
        Q['_res'] = res
        out(f'==== IR-compare · 단계 {st} · 설정 sha256 {Q["_sha"][:8]}…')
        gpu = require_gpu(device) if st in GPU_STAGES else None
        if gpu:
            out(f'GPU {device}: {gpu}')
        import prepare
        t0 = time.time(); data = prepare.ensure(Q, out); root = data['root']
        cfg = dict(Q, device=str(device))
        ur = os.path.join(res, 'uiunet')
        cfg['_P'] = dict(res=ur, evals=os.path.join(ur, 'evals'), logs=os.path.join(ur, 'logs'), runs=os.path.join(ur, 'runs'),
                         build=Q['paths']['build'], view=Q['paths']['view'], root=root)
        ep = os.path.join(res, 'logs', 'ENV.json'); envs = rjson(ep) if os.path.exists(ep) else []
        envs.append(dict(env_now(gpu), stages=[st])); wjson(ep, envs)
        est = Estimate(out)
        if st == 'filter':
            from filter import stage as FS
            est.start([st], dict(filter=FS.todo(Q, root, device)))
            FS.run(Q, root, out, device, est)
        elif st == 'uiunet':
            from uiunet import stage as US
            est.start([st], dict(uiunet=US.todo(cfg)))
            US.run(cfg, out, est)
        elif st == 'report':
            import report
            report.make(Q, cfg, root, res, out)
        out(f'==== 단계 {st} 끝 · {time.time() - t0:.0f}초 · 결과 {res}')
        return 0
    except Stop as e:
        out(f'!! 멈춤: {e}'); return 2
    except KeyboardInterrupt:
        out('!! 사용자가 끊음 — 같은 명령을 다시 실행하면 이어 간다'); return 130
    except Exception as e:
        import traceback
        out('!! 오류: ' + repr(e)); out(traceback.format_exc())
        out('같은 명령을 다시 실행하면 끝난 곳 다음부터 이어 간다. 같은 오류가 되풀이되면 README.md 5절(자주 나는 오류)을 본다')
        return 1


if __name__ == '__main__':
    sys.exit(main())
