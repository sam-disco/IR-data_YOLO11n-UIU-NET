# 파일 대응표 — IR-compare ← IR-night-filter 14차 수정4

기준 저장소 zip sha256 `645aa0515b3f73c5ed385da1d3ff12968de892206bfacb7862d03d4585e3a9f8`.
「그대로」 = 그 정의(함수 · 클래스 · 상수)의 글자가 원본과 바이트까지 같다(정의 sha256 앞 12자리가 원본과 같음). 「고침」 = 고친 곳 · 이유를 적었다. 「새로」 = 이 패키지에서 새로 쓴 것.
이 표는 tools/filemap.py가 두 폴더를 읽어 만든다(손으로 고치지 않는다).

## 1. 파일

| 새 파일 | 새 파일 sha256 | 원본 파일 | 원본 파일 sha256 | 그대로 | 고침 | 새로 |
|---|---|---|---|---|---|---|
| `common/__init__.py` | `324664cbe14340abbfd8309938e6ceedd9cf3de27573e90a51293d6c17f19861` | `src/irfilter/__init__.py` | `8a6b45518b913734fe73248268c241830a659f072b6bfa08477bd3a1264fe361` | 13 | 1 | 0 |
| `common/metrics.py` | `9400333efae511e6fa48d5e0d96cf45240092569f22742bfc9932b48130fc8ae` | `src/irfilter/metrics.py` | `de3632dd82fc7685aa00cc8e7e40837d82c51eff5db0cd0f099491d70ef9c6b3` | 17 | 0 | 0 |
| `common/hituav.py` | `faa654d53fe0b1bb1bc826a2a513c29034e495d1858d50a9b4d55c5660e98782` | `src/irfilter/data_hituav.py` | `e57c7bb49ec581d5b8027a7798664ffdb5de7c111b524538d5826dff69b4dc51` | 18 | 1 | 3 |
| `common/filters.py` | `c805adb95cdd632db2495177fdaa07d597b856dead89a5f20ae36b723ea2f5fe` | `src/irfilter/filters.py` | `48183de6f631b74faf66b6275313338db15e294ba7f5155f88dbe7007c5b4fc4` | 8 | 1 | 0 |
| `common/paths.py` | `40ff61fc3c622abafa7cd0c236ad9cc9f2bba933fecf1bc93cf8462cd84dc920` | — (새 파일) | — | 0 | 0 | 2 |
| `common/est.py` | `01c5773d4d6ae3b53a45ebf2f27528cc9cf6fa026dc0276d6b6c06032a3bf9cd` | — (새 파일) | — | 0 | 0 | 4 |
| `prepare.py` | `56b0618b4117934befc504b4272d4e5a6b04f709383384c262e2ebf2b2d724d9` | — (새 파일) | — | 0 | 1 | 7 |
| `filter/__init__.py` | `a3e5fca9af45e62656a625e60f836305513d76b4a187036ad8c10ee3fc3afd20` | — (새 파일) | — | 0 | 0 | 0 |
| `filter/train.py` | `68820efbd406c2628a278fe5cb5d7254b5886d1e45b01165afe67ba28a8aba90` | `src/irfilter/train.py` | `95e6334cd4851de83a0b9d5b37ef789d92f66f52e8362156a4d0e38cda9ba469` | 8 | 4 | 0 |
| `filter/evaluate.py` | `68c19db874eb70446a8289fced2ecf6e7006bed818d1e6ccdc801b226f7dd0c7` | `src/irfilter/evaluate.py` | `5ad8d5655ef05d81bcd65749d7b9f3de209fce998ab30ee8e96baa6bdf772bfe` | 0 | 2 | 0 |
| `filter/stage.py` | `9fc566a16e81358fad22c59294cbc137db979368d181493b788f25070dd7178c` | — (새 파일) | — | 0 | 3 | 6 |
| `uiunet/__init__.py` | `3ab4df53c08e2aac3e28266bd5d3bc1313ebf3ca10ed2e86af58455e1b1d9e92` | — (새 파일) | — | 0 | 0 | 0 |
| `uiunet/u_data.py` | `0f6133a6e11f854f8f2cfa296d0d948059c3b4530a53b707364dfb39ca7d4616` | `src/irfilter/u_data.py` | `3e699bd8b18c2ae7f54c28bbbb1f8a05319cfe16350289db5467435c02d58a00` | 25 | 2 | 0 |
| `uiunet/u_net.py` | `517c38750470f782d027396540c5281f47deaa80019dccde244caee2cca817a5` | `src/irfilter/u_net.py` | `6eea0afed6d605a4b9c19ef391443c3247507d44232bdb19db2d40fae843b99d` | 17 | 1 | 0 |
| `uiunet/stage.py` | `a61834353522858ad0fe75c171876ada4ca5d072593208f9b258499a1dc47757` | `src/irfilter/u2_stage.py` | `3877ff36179a9729b64d8306eb515a97ae62d3738a0ebebcfb3b3a62c1f91567` | 11 | 12 | 5 |
| `report.py` | `91886a401825bc563a5124e4b1eb61aaadc4a94c76dcbc5e04ce31f942ccde1b` | — (새 파일) | — | 0 | 0 | 10 |
| `run_all.py` | `ab330af050f2d8e576f5646f5ff45af7b20c0ec52d392096b4fef3ffa9c38d43` | — (새 파일) | — | 0 | 0 | 8 |

고친 정의가 가져온 원본이 위 표의 원본 파일 밖에 있는 경우(2절의 「원본 파일」 칸): `src/irfilter/pipeline.py` `133b9fd31137d9603b7bfa77319b98ed8539f6d37bb7fe09a1f3f4aacd14e273` · `src/irfilter/data_hituav.py` `e57c7bb49ec581d5b8027a7798664ffdb5de7c111b524538d5826dff69b4dc51` · `src/irfilter/train.py` `95e6334cd4851de83a0b9d5b37ef789d92f66f52e8362156a4d0e38cda9ba469` · `src/irfilter/u2_stage.py` `3877ff36179a9729b64d8306eb515a97ae62d3738a0ebebcfb3b3a62c1f91567`

옮기지 않은 원본 파일: 다른 데이터 · 다른 실험 단계의 코드와 필터 계산 · 빌드 · 판정 코드는 이 패키지에 없다. `assets/split_night_date_v1.csv`(baa3b1a8…)는 기존 저장소의 것 그대로, `assets/MANIFEST_ref_*.csv`는 기존 빌드 MANIFEST(160f1e95… · 6dee21ff…)에서 원영상 · 제안 필터 행만 고른 것, `assets/regen_split_night_date_v1.py`는 프로젝트 원본의 글자 그대로다.

## 2. 정의마다

| 새 파일 | 이름 | 원본 파일 | 원본 이름 | 상태 | 정의 sha256 | 고친 곳 · 이유 |
|---|---|---|---|---|---|---|
| `common/__init__.py` | `ROOT` | `__init__.py` | `ROOT` | 고침 | `56678602f851` | 패키지 뿌리가 한 단계 위(common/의 부모)라서 경로 계산을 바꿈 |
| `common/__init__.py` | `Stop` | `__init__.py` | `Stop` | 그대로 | `771d87d0a75e` |  |
| `common/__init__.py` | `now` | `__init__.py` | `now` | 그대로 | `01723576ce68` |  |
| `common/__init__.py` | `sha_file` | `__init__.py` | `sha_file` | 그대로 | `49fd26730c67` |  |
| `common/__init__.py` | `sha_bytes` | `__init__.py` | `sha_bytes` | 그대로 | `3e699aa4d547` |  |
| `common/__init__.py` | `arr_sha` | `__init__.py` | `arr_sha` | 그대로 | `035c84c52cd7` |  |
| `common/__init__.py` | `hash_ok` | `__init__.py` | `hash_ok` | 그대로 | `d02ae2f66c4e` |  |
| `common/__init__.py` | `wjson` | `__init__.py` | `wjson` | 그대로 | `c22028f11ac7` |  |
| `common/__init__.py` | `rjson` | `__init__.py` | `rjson` | 그대로 | `3e91dfa88540` |  |
| `common/__init__.py` | `dump_gz` | `__init__.py` | `dump_gz` | 그대로 | `aa2046bf147e` |  |
| `common/__init__.py` | `load_gz` | `__init__.py` | `load_gz` | 그대로 | `a5c8eaf247a4` |  |
| `common/__init__.py` | `wcsv` | `__init__.py` | `wcsv` | 그대로 | `1fc009f87877` |  |
| `common/__init__.py` | `rcsv` | `__init__.py` | `rcsv` | 그대로 | `60c351b0c52a` |  |
| `common/__init__.py` | `Log` | `__init__.py` | `Log` | 그대로 | `813fb3e61f12` |  |
| `common/metrics.py` | `IOUV` | `metrics.py` | `IOUV` | 그대로 | `f5ac563d7183` |  |
| `common/metrics.py` | `BINS` | `metrics.py` | `BINS` | 그대로 | `c13ca0d83fcc` |  |
| `common/metrics.py` | `NAMES` | `metrics.py` | `NAMES` | 그대로 | `d263592dfa76` |  |
| `common/metrics.py` | `iou_mat` | `metrics.py` | `iou_mat` | 그대로 | `055f8d21dec4` |  |
| `common/metrics.py` | `ioa` | `metrics.py` | `ioa` | 그대로 | `e5d265e19f07` |  |
| `common/metrics.py` | `match` | `metrics.py` | `match` | 그대로 | `6ab48c5e35ee` |  |
| `common/metrics.py` | `image_records` | `metrics.py` | `image_records` | 그대로 | `88c1cd774225` |  |
| `common/metrics.py` | `_X101` | `metrics.py` | `_X101` | 그대로 | `86045d9700b5` |  |
| `common/metrics.py` | `_ap_per_class` | `metrics.py` | `_ap_per_class` | 그대로 | `420e3eca81aa` |  |
| `common/metrics.py` | `ap_table` | `metrics.py` | `ap_table` | 그대로 | `215f6008559b` |  |
| `common/metrics.py` | `operating_points` | `metrics.py` | `operating_points` | 그대로 | `49b78df42835` |  |
| `common/metrics.py` | `on_line` | `metrics.py` | `on_line` | 그대로 | `701f6dc65f68` |  |
| `common/metrics.py` | `summarize` | `metrics.py` | `summarize` | 그대로 | `9ed0c51d0108` |  |
| `common/metrics.py` | `read_eval` | `metrics.py` | `read_eval` | 그대로 | `f713b688f285` |  |
| `common/metrics.py` | `load` | `metrics.py` | `load` | 그대로 | `04900272a563` |  |
| `common/metrics.py` | `ap_on` | `metrics.py` | `ap_on` | 그대로 | `7b8fd8ff4a2f` |  |
| `common/metrics.py` | `mean_sd` | `metrics.py` | `mean_sd` | 그대로 | `cf4dcf5d7bf3` |  |
| `common/hituav.py` | `SPLIT_SHA` | `data_hituav.py` | `SPLIT_SHA` | 그대로 | `123c2a95516a` |  |
| `common/hituav.py` | `DATES` | `data_hituav.py` | `DATES` | 그대로 | `bfb7c2c6b246` |  |
| `common/hituav.py` | `YOLO_CLS` | `data_hituav.py` | `YOLO_CLS` | 그대로 | `d64548c00085` |  |
| `common/hituav.py` | `H,W` | `data_hituav.py` | `H,W` | 그대로 | `a9c0f9a42137` |  |
| `common/hituav.py` | `sha_file` | `data_hituav.py` | `sha_file` | 그대로 | `49fd26730c67` |  |
| `common/hituav.py` | `arr_sha` | `data_hituav.py` | `arr_sha` | 그대로 | `b607477b7263` |  |
| `common/hituav.py` | `make_split` | `data_hituav.py` | `make_split` | 그대로 | `95a2f8905bac` |  |
| `common/hituav.py` | `check_split` | `data_hituav.py` | `check_split` | 그대로 | `1d2a0d8dec6b` |  |
| `common/hituav.py` | `load_split` | `data_hituav.py` | `load_split` | 그대로 | `8dc0d3b31ab6` |  |
| `common/hituav.py` | `yolo_lines` | `data_hituav.py` | `yolo_lines` | 그대로 | `5ea4cff1b8a0` |  |
| `common/hituav.py` | `make_input` | `data_hituav.py` | `make_input` | 그대로 | `0ca38c133694` |  |
| `common/hituav.py` | `data_yaml` | `data_hituav.py` | `data_yaml` | 그대로 | `3055cd5004fb` |  |
| `common/hituav.py` | `_one` | `data_hituav.py` | `_one` | 그대로 | `8a10e9435857` |  |
| `common/hituav.py` | `build` | `data_hituav.py` | `build` | 그대로 | `c48cbb879ebb` |  |
| `common/hituav.py` | `read_manifest` | `data_hituav.py` | `read_manifest` | 그대로 | `ffc75a20ed19` |  |
| `common/hituav.py` | `compare_manifest` | `data_hituav.py` | `compare_manifest` | 그대로 | `2380a1186876` |  |
| `common/hituav.py` | `verify` | `data_hituav.py` | `verify` | 그대로 | `249d0339502e` |  |
| `common/hituav.py` | `_download` | `data_hituav.py` | `_download` | 그대로 | `be778288779f` |  |
| `common/hituav.py` | `setup_hituav` | `data_hituav.py` | `setup_hituav` | 고침 | `488efd6b8074` | 오류 때의 안내 문장(이 패키지의 명령으로) · 패키지 폴더를 옮겨 기록의 경로가 달라졌으면 푼 폴더를 다시 찾음. zip 해시 확인 · 풀기 · 분할 다시 만들기는 같음 |
| `common/hituav.py` | `ORIG_SPLITS` | — | — | 새로 | `1ce1fbfc68eb` |  |
| `common/hituav.py` | `official_lists` | — | — | 새로 | `a27efc45d68d` |  |
| `common/hituav.py` | `official_data` | — | — | 새로 | `c6ae308d5f96` |  |
| `common/filters.py` | `none` | `filters.py` | `none` | 그대로 | `2e05dc4ae39e` |  |
| `common/filters.py` | `_col_row` | `filters.py` | `_col_row` | 그대로 | `b7600e0a3662` |  |
| `common/filters.py` | `_add` | `filters.py` | `_add` | 그대로 | `791c803c24fc` |  |
| `common/filters.py` | `_ring_quantiles` | `filters.py` | `_ring_quantiles` | 그대로 | `7b490ed27d4b` |  |
| `common/filters.py` | `_fr` | `filters.py` | `_fr` | 그대로 | `450df86de59b` |  |
| `common/filters.py` | `ring_quantiles` | `filters.py` | `ring_quantiles` | 그대로 | `eab4cbca22c8` |  |
| `common/filters.py` | `hollow_rank` | `filters.py` | `hollow_rank` | 그대로 | `b7bc302ed46d` |  |
| `common/filters.py` | `FILTERS` | `filters.py` | `FILTERS` | 고침 | `a7b47162de2a` | 표를 두 줄로 줄임: 필터 없음 · 제안 필터(hollow_rank). 다른 필터는 옮기지 않음 |
| `common/filters.py` | `apply` | `filters.py` | `apply` | 그대로 | `9b7d06f9113c` |  |
| `common/paths.py` | `path_problem` | — | — | 새로 | `e7f8e0a7ae6d` |  |
| `common/paths.py` | `check_paths` | — | — | 새로 | `de0325cda8a6` |  |
| `common/est.py` | `START` | — | — | 새로 | `37834c01a692` |  |
| `common/est.py` | `NAME` | — | — | 새로 | `853cb55c4cc8` |  |
| `common/est.py` | `hm` | — | — | 새로 | `55863ca0fcbe` |  |
| `common/est.py` | `Estimate` | — | — | 새로 | `2a2cec1a2ae0` |  |
| `prepare.py` | `conds` | — | — | 새로 | `f8cc52376914` |  |
| `prepare.py` | `reference` | — | — | 새로 | `5294ac7ed6c4` |  |
| `prepare.py` | `FOLDERS` | — | — | 새로 | `4418bb1cc44d` |  |
| `prepare.py` | `manifests` | — | — | 새로 | `16fbbfdc5889` |  |
| `prepare.py` | `against_ref` | — | — | 새로 | `5e44bd2f6d9e` |  |
| `prepare.py` | `check_built` | — | — | 새로 | `592aa14f279a` |  |
| `prepare.py` | `check_official` | — | — | 새로 | `2768317ad856` |  |
| `prepare.py` | `ensure` | `u2_stage.py · pipeline.py` | `build_u2 · step_build` | 고침 | `5bf317cea0d4` | 조건 둘(원영상 · 제안 필터) · 야간 1,981장 전부를 만듦(기존 저장 폴더 train · val · test 그대로) · 기준 대조를 파일 전체 해시가 아니라 영상마다의 행으로 함(기준 = 기존 MANIFEST에서 두 조건의 행 — 기준이 있는 1,593장 × 2) · 다르면 폴더를 옮겨 두고 다시 만듦 |
| `filter/train.py` | `WEIGHTS` | `train.py` | `WEIGHTS` | 고침 | `91e5d12e094c` | 해시 표에 yolo11n.pt만 둠(다른 모형은 쓰지 않음) |
| `filter/train.py` | `ULTRALYTICS_VERSION` | `train.py` | `ULTRALYTICS_VERSION` | 그대로 | `f4f3be3d8843` |  |
| `filter/train.py` | `PROGRESS` | `train.py` | `PROGRESS` | 그대로 | `51ed51ebda34` |  |
| `filter/train.py` | `fold_tag` | `train.py` | `fold_tag` | 그대로 | `3c9148a8e380` |  |
| `filter/train.py` | `run_name` | `train.py` | `run_name` | 그대로 | `060898e51197` |  |
| `filter/train.py` | `log` | `train.py` | `log` | 그대로 | `d37deeed9e87` |  |
| `filter/train.py` | `env_record` | `train.py` | `env_record` | 그대로 | `ddc3af0fd244` |  |
| `filter/train.py` | `train_args` | `train.py` | `train_args` | 그대로 | `d22ac1e46e01` |  |
| `filter/train.py` | `train_state` | `train.py` | `train_state` | 그대로 | `37256603881b` |  |
| `filter/train.py` | `data_yaml_for` | `train.py` | `data_yaml_for` | 고침 | `efaa8843928e` | 날짜 분할 · 접기 목록 대신 배포 분할 목록(common.hituav.official_data)을 씀 |
| `filter/train.py` | `preflight` | `train.py` | `preflight` | 고침 | `e79db6bb7649` | assert 대신 안내가 붙은 멈춤 · ultralytics 판이 다르면 멈추지 않고 알림 · 해시 표는 yolo11n.pt만 |
| `filter/train.py` | `train_one` | `train.py` | `train_one` | 고침 | `104551be0a19` | callbacks 인자 추가(첫 epoch 시간 재기 · 손실 NaN/Inf 멈춤을 걸려고). 학습 인자 · 기록은 같음 |
| `filter/evaluate.py` | `eval_one` | `evaluate.py` | `eval_one` | 고침 | `090cc951f3cc` | metrics를 common에서 불러오는 한 줄 |
| `filter/evaluate.py` | `eval_done` | `evaluate.py` | `eval_done` | 고침 | `54162c53119a` | metrics를 common에서 불러오는 한 줄 |
| `filter/stage.py` | `TAG` | — | — | 새로 | `1bd295d42666` |  |
| `filter/stage.py` | `make_cfg` | `train.py` | `v2cfg` | 고침 | `acb51cf5a2b7` | 경로를 이 패키지 꼴로(입력 영상 data/build · 결과 results/filter) · 조건 둘 · 실행 이름 머리 official_ · HIT-UAV 폴더를 인자로. hyp · epochs · eval은 같음 |
| `filter/stage.py` | `ensure_weights` | `data_hituav.py` | `setup_weights` | 고침 | `9e7d86c71fac` | yolo11n.pt 하나만 · weights/ 바로 아래에 받음 · 받지 못하면 안내. 주소 · 해시는 같음(해시 확인은 preflight) |
| `filter/stage.py` | `jobs` | — | — | 새로 | `8275344c682a` |  |
| `filter/stage.py` | `todo` | — | — | 새로 | `31e92ecff52b` |  |
| `filter/stage.py` | `set_aside` | — | — | 새로 | `79ea722f30e3` |  |
| `filter/stage.py` | `finite` | — | — | 새로 | `cfb0ac870f94` |  |
| `filter/stage.py` | `gt_of` | — | — | 새로 | `e306dc567cb4` |  |
| `filter/stage.py` | `run` | `train.py` | `cmd_loop` | 고침 | `29683fc4f728` | 반쯤 남은 학습은 멈추지 않고 폴더를 옮겨 둔 뒤 다시 함 · 평가 집합 = 배포 분할 test · val · 첫 epoch 뒤 남은 시간 다시 계산 · 손실 NaN/Inf 멈춤 |
| `uiunet/u_data.py` | `MEAN` | `u_data.py` | `MEAN` | 그대로 | `411e11b24e28` |  |
| `uiunet/u_data.py` | `STD` | `u_data.py` | `STD` | 그대로 | `5725a8c3326c` |  |
| `uiunet/u_data.py` | `LIST_COLS` | `u_data.py` | `LIST_COLS` | 그대로 | `6ea688a5faf9` |  |
| `uiunet/u_data.py` | `_span` | `u_data.py` | `_span` | 그대로 | `37b11151ee98` |  |
| `uiunet/u_data.py` | `draw_mask` | `u_data.py` | `draw_mask` | 그대로 | `d587acd84da2` |  |
| `uiunet/u_data.py` | `weight_map` | `u_data.py` | `weight_map` | 그대로 | `5213aef38e8d` |  |
| `uiunet/u_data.py` | `person_boxes_txt` | `u_data.py` | `person_boxes_txt` | 그대로 | `242b9dda4ef0` |  |
| `uiunet/u_data.py` | `hit_boxes` | `u_data.py` | `hit_boxes` | 그대로 | `535cc1f8db9b` |  |
| `uiunet/u_data.py` | `_extent` | `u_data.py` | `_extent` | 그대로 | `33afffeaebba` |  |
| `uiunet/u_data.py` | `unscale_box` | `u_data.py` | `unscale_box` | 그대로 | `15c63c432b28` |  |
| `uiunet/u_data.py` | `components` | `u_data.py` | `components` | 그대로 | `6e7ed86dc415` |  |
| `uiunet/u_data.py` | `normalize_fixed` | `u_data.py` | `normalize_fixed` | 그대로 | `822933147258` |  |
| `uiunet/u_data.py` | `NORMS` | `u_data.py` | `NORMS` | 고침 | `351e8aad37dc` | 'fixed'(÷255 + ImageNet 상수)만 둠 — 'max'는 쓰지 않는 예전 방식 |
| `uiunet/u_data.py` | `TILE` | `u_data.py` | `TILE` | 그대로 | `7b54c57d226f` |  |
| `uiunet/u_data.py` | `TILE_X0` | `u_data.py` | `TILE_X0` | 그대로 | `259d65448f08` |  |
| `uiunet/u_data.py` | `TILE_Y0` | `u_data.py` | `TILE_Y0` | 그대로 | `ec8bad7171c3` |  |
| `uiunet/u_data.py` | `tiles_xy` | `u_data.py` | `tiles_xy` | 그대로 | `f11edad4551b` |  |
| `uiunet/u_data.py` | `stitch_max` | `u_data.py` | `stitch_max` | 그대로 | `501140956f30` |  |
| `uiunet/u_data.py` | `pad_to` | `u_data.py` | `pad_to` | 그대로 | `a70b2c0c8ac4` |  |
| `uiunet/u_data.py` | `crop_flip` | `u_data.py` | `crop_flip` | 그대로 | `a914bfad1963` |  |
| `uiunet/u_data.py` | `list_rows` | `u_data.py` | `list_rows` | 고침 | `59e15153ec1c` | HIT-UAV 행만 만듦(다른 학습 데이터를 섞는 인자를 뺌). HIT-UAV 행의 내용 · 정렬은 같음 |
| `uiunet/u_data.py` | `stem_of_path` | `u_data.py` | `stem_of_path` | 그대로 | `ae7edcb4d720` |  |
| `uiunet/u_data.py` | `check_row` | `u_data.py` | `check_row` | 그대로 | `589773159c03` |  |
| `uiunet/u_data.py` | `read_list` | `u_data.py` | `read_list` | 그대로 | `3d47c5a8af8e` |  |
| `uiunet/u_data.py` | `load_item` | `u_data.py` | `load_item` | 그대로 | `25486c1753ed` |  |
| `uiunet/u_data.py` | `U2Dataset` | `u_data.py` | `U2Dataset` | 그대로 | `97601f237d71` |  |
| `uiunet/u_data.py` | `EpochSampler` | `u_data.py` | `EpochSampler` | 그대로 | `c98bc71732ad` |  |
| `uiunet/u_net.py` | `fetch` | `u_net.py` | `fetch` | 그대로 | `7f855a373f40` |  |
| `uiunet/u_net.py` | `_dir` | `u_net.py` | `_dir` | 그대로 | `1529d65b9f5b` |  |
| `uiunet/u_net.py` | `model_class` | `u_net.py` | `model_class` | 고침 | `ed6add1475cc` | 해시가 다를 때의 안내 문장만(이 패키지의 명령으로) |
| `uiunet/u_net.py` | `build_model` | `u_net.py` | `build_model` | 그대로 | `cb599f291b18` |  |
| `uiunet/u_net.py` | `set_det` | `u_net.py` | `set_det` | 그대로 | `ec27d7454df8` |  |
| `uiunet/u_net.py` | `loss_fn` | `u_net.py` | `loss_fn` | 그대로 | `b6b2cbb55c99` |  |
| `uiunet/u_net.py` | `load_net` | `u_net.py` | `load_net` | 그대로 | `61807d2dbf89` |  |
| `uiunet/u_net.py` | `prob_maps` | `u_net.py` | `prob_maps` | 그대로 | `c2606ce91d24` |  |
| `uiunet/u_net.py` | `soft_iou` | `u_net.py` | `soft_iou` | 그대로 | `7c17d6263544` |  |
| `uiunet/u_net.py` | `loss_u2` | `u_net.py` | `loss_u2` | 그대로 | `d9f4473b78f7` |  |
| `uiunet/u_net.py` | `NonFinite` | `u_net.py` | `NonFinite` | 그대로 | `ca02c4e32b6b` |  |
| `uiunet/u_net.py` | `amp_mode` | `u_net.py` | `amp_mode` | 그대로 | `4e833c81df05` |  |
| `uiunet/u_net.py` | `SPEED_DEFAULT` | `u_net.py` | `SPEED_DEFAULT` | 그대로 | `584b05593d80` |  |
| `uiunet/u_net.py` | `speed_of` | `u_net.py` | `speed_of` | 그대로 | `d264004c8083` |  |
| `uiunet/u_net.py` | `StepAcc` | `u_net.py` | `StepAcc` | 그대로 | `1efe84d0af88` |  |
| `uiunet/u_net.py` | `train_step` | `u_net.py` | `train_step` | 그대로 | `27eb4f2e0be0` |  |
| `uiunet/u_net.py` | `train_run2` | `u_net.py` | `train_run2` | 그대로 | `fa97355ba7a7` |  |
| `uiunet/u_net.py` | `run_state` | `u_net.py` | `run_state` | 그대로 | `a5d395937a35` |  |
| `uiunet/stage.py` | `PROGRESS` | — | — | 새로 | `80d67f0dec74` |  |
| `uiunet/stage.py` | `P` | `u2_stage.py` | `P` | 고침 | `9860fc768f44` | 경로를 설정에서 만들지 않고 run_all.py가 넣어 준 것을 돌려줌 |
| `uiunet/stage.py` | `variant` | — | — | 새로 | `1481276d1f03` |  |
| `uiunet/stage.py` | `u_name` | `u2_stage.py` | `u_name` | 고침 | `3115b26e14bb` | 실행 이름 = uiunet_<마스크 방식>_<조건>_s<seed>(학습 방식 · 접기 대신 마스크 방식) |
| `uiunet/stage.py` | `run_dir` | `u2_stage.py` | `run_dir` | 고침 | `00cc709a35c0` | 인자가 (마스크 방식, 조건, seed) |
| `uiunet/stage.py` | `eval_path` | `u2_stage.py` | `eval_path` | 고침 | `6a846b9e1d31` | 인자가 (마스크 방식, 조건, seed, 분할) · 파일 이름 끝이 분할 이름 |
| `uiunet/stage.py` | `dev_of` | `u2_stage.py` | `dev_of` | 그대로 | `6aa4a6fb0ddb` |  |
| `uiunet/stage.py` | `rule_parse` | `u2_stage.py` | `rule_parse` | 그대로 | `78339961ec02` |  |
| `uiunet/stage.py` | `read_png` | `u2_stage.py` | `read_png` | 그대로 | `c30fec53157d` |  |
| `uiunet/stage.py` | `person_diag` | `u2_stage.py` | `person_diag` | 그대로 | `ae2679e85a4f` |  |
| `uiunet/stage.py` | `predict_rules` | `u2_stage.py` | `predict_rules` | 그대로 | `66e650340d22` |  |
| `uiunet/stage.py` | `q3` | `u2_stage.py` | `q3` | 그대로 | `d24f66401143` |  |
| `uiunet/stage.py` | `diag_summary` | `u2_stage.py` | `diag_summary` | 그대로 | `1d8d2f47702f` |  |
| `uiunet/stage.py` | `ap_rule` | `u2_stage.py` | `ap_rule` | 그대로 | `61420a8e4ac3` |  |
| `uiunet/stage.py` | `eval_set` | `u2_stage.py` | `eval_set` | 그대로 | `4ab2b4ae7dc6` |  |
| `uiunet/stage.py` | `eval_file` | `u2_stage.py` | `eval_file` | 그대로 | `41bd6faf0a79` |  |
| `uiunet/stage.py` | `rule_runs` | `u2_stage.py` | `rule_runs` | 그대로 | `408ab9b5b3b5` |  |
| `uiunet/stage.py` | `gt_src` | `u2_stage.py` | `gt_src` | 고침 | `a5e76db25bc7` | 날짜 분할 · 접기 대신 배포 분할 하나의 목록을 씀. 반환 꼴은 같음 |
| `uiunet/stage.py` | `make_view` | `u2_stage.py` | `make_view · view_items` | 고침 | `fc84bdad71f5` | 학습 목록 = 배포 train(날짜 접기 · 다른 학습 데이터 가지를 뺌). 행의 내용 · 정렬은 같음 |
| `uiunet/stage.py` | `list_rows` | `u2_stage.py` | `view_rows` | 고침 | `c3f137c94d1f` | 사전 점검 단계가 적어 둔 해시와의 대조를 뺌(목록 파일과 그 기록의 대조는 같음) |
| `uiunet/stage.py` | `ulog` | `u2_stage.py` | `ulog` | 고침 | `2ce3fd723df9` | 진행 기록 칸을 줄임(시간 한도 계산용 칸을 뺌) |
| `uiunet/stage.py` | `set_aside` | — | — | 새로 | `db7c912d7cb1` |  |
| `uiunet/stage.py` | `run_one` | `u2_stage.py` | `run_one` | 고침 | `365f6271a16b` | 정밀도 · 배치 · 손실을 사전 단계 상태 대신 설정에서 읽음(기존 실행 값 FP32 · 4 · A) · 일정 · 시간 한도 확인을 뺌 · 학습 도중 검증 기록을 뺌 · 반쯤 남은 폴더는 옮겨 둔 뒤 다시 함 · 학습 목록 = 배포 train · 정답 마스크 방식을 인자로 받음. train_run2에 넘기는 값의 꼴은 같음 |
| `uiunet/stage.py` | `eval_one` | `u2_stage.py` | `eval_one` | 고침 | `5cc2f32180d8` | 다른 가중치로 만든 평가 파일이 남아 있으면 멈추지 않고 옮겨 둔 뒤 다시 평가 · 평가 집합 = 배포 분할 하나 · 진행 기록 꼴. eval_file에 넘기는 값의 꼴은 같음 |
| `uiunet/stage.py` | `ap_of` | `u2_stage.py` | `ap_seeds` | 고침 | `682238bb1bc8` | 평가 파일 하나 · seed 하나의 값만 돌려줌. 셈(rule_runs → metrics.ap_on)은 같음 |
| `uiunet/stage.py` | `jobs` | — | — | 새로 | `558961d92b94` |  |
| `uiunet/stage.py` | `todo` | — | — | 새로 | `8b57c7dd2fa4` |  |
| `uiunet/stage.py` | `run` | `u2_stage.py` | `stage_p2` | 고침 | `76c713d450ee` | 사전 단계 확인 · 시간 한도 · 규칙 고정 확인을 빼고 seed 0만 · (마스크 방식 × 조건)마다 학습 뒤 바로 평가 · 남은 시간 다시 계산 |
| `report.py` | `HEAD` | — | — | 새로 | `0c12b54a61ba` |  |
| `report.py` | `NONE` | — | — | 새로 | `4ddf7b7b6214` |  |
| `report.py` | `MASK` | — | — | 새로 | `799ae301b743` |  |
| `report.py` | `f2` | — | — | 새로 | `ec86326bdd16` |  |
| `report.py` | `sg` | — | — | 새로 | `6061071292fe` |  |
| `report.py` | `sub` | — | — | 새로 | `21f11c14dfcb` |  |
| `report.py` | `yolo_values` | — | — | 새로 | `930b30f27d61` |  |
| `report.py` | `uiunet_values` | — | — | 새로 | `b12a89658387` |  |
| `report.py` | `times` | — | — | 새로 | `332562b9e91d` |  |
| `report.py` | `make` | — | — | 새로 | `ada8f0ea2c0a` |  |
| `run_all.py` | `HERE` | — | — | 새로 | `23b6448daffe` |  |
| `run_all.py` | `STAGES` | — | — | 새로 | `2acdf71ee511` |  |
| `run_all.py` | `GPU_STAGES` | — | — | 새로 | `79ca0dacf935` |  |
| `run_all.py` | `load_config` | — | — | 새로 | `05137542a4fa` |  |
| `run_all.py` | `require_gpu` | — | — | 새로 | `d809c4540440` |  |
| `run_all.py` | `env_now` | — | — | 새로 | `d7854c18ee6c` |  |
| `run_all.py` | `run_stages` | — | — | 새로 | `a5b4913a36a8` |  |
| `run_all.py` | `main` | — | — | 새로 | `a7361af732b8` |  |
