"""보고서 results/REPORT.md · REPORT.json — 평가 파일을 다시 채점해 네 모형의 Person AP50 표를 만든다. torch 없이 돈다.
채점 정의: 확신도 순 · 남은 정답 중 IoU 최대 · DontCare IoA ≥ 0.5 미매칭 제외 · [0, r, r끝, 1] 포락선 · 101점. 정답은 HIT-UAV b53106c normal_json이다."""
import os
from common import now, wjson, rjson, rcsv
from common import hituav as D, metrics as M
from common.est import hm

HEAD = 'seed 1개 실행 — 확인용, 결론에 쓰지 않음'
NONE = '아직 없음'
MASK = {'ellipse': '0.5배 타원', 'box': '상자 채움'}


def f2(x):
    return NONE if x is None else f'{x:.2f}'


def sg(x):
    return '—' if x is None else f'{x:+.2f}'


def sub(a, b):
    return None if (a is None or b is None) else a - b


def yolo_values(Q, root):
    """{조건: {분할: Person AP50(점) 또는 None}} — 평가 파일을 common.metrics.load · ap_on으로 다시 채점"""
    from filter import stage as FS, train as T
    L = D.official_lists(root, Q['paths']['split_csv']); cfg = FS.make_cfg(Q, root, '0', ''); out = {}
    for c in Q['filter']['conds']:
        out[c] = {}; s = Q['filter']['seeds'][0]
        for sp in Q['split']['eval']:
            p = os.path.join(cfg['P']['evals'], f'{T.run_name(cfg, c, s)}_{sp}.json.gz')
            if not os.path.exists(p):
                out[c][sp] = None; continue
            gt = FS.gt_of(L[sp]); stems = sorted(k[:-4] for k in gt)
            runs, _ = M.load([p], gt); (nm, sd), = runs.items()
            out[c][sp] = 100 * M.ap_on(sd[s], stems, 'Person')
    return out


def uiunet_values(cfg):
    """{마스크: {조건: {분할: Person AP50(점) 또는 None}}} — 평가 파일을 출력 규칙 하나로 다시 채점"""
    from uiunet import stage as US
    out = {}; s = cfg['u2']['seeds'][0]
    for m in cfg['u2']['masks']:
        out[m] = {c: {sp: (100 * US.ap_of(cfg, m, c, s, sp)) if os.path.exists(US.eval_path(cfg, m, c, s, sp)) else None
                      for sp in cfg['split']['eval']} for c in cfg['u2']['conds']}
    return out


def times(Q, cfg, root, res):
    """실행마다 걸린 시간(초): 학습은 run_record, 평가는 진행 기록 · 평가 파일에서(평가 = 두 분할의 합). 없는 칸은 None"""
    from filter import stage as FS, train as T
    from uiunet import stage as US
    rows = []; pl = os.path.join(res, 'filter', 'logs', 'progress.csv'); ev = {}
    if os.path.exists(pl):
        for r in rcsv(pl):
            if r['step'] == 'eval' and r['status'] == 'ok':
                ev[(r['cond'], r['seed'], r['split'])] = float(r['seconds'])
    tot = lambda v: None if any(x is None for x in v) else sum(v)
    c2 = FS.make_cfg(Q, root, '0', '')
    for c, s in FS.jobs(Q):
        rr = os.path.join(c2['P']['runs'], T.run_name(c2, c, s), 'run_record.json')
        rows.append(dict(stage='YOLO11n', name=T.run_name(c2, c, s), train_s=rjson(rr).get('wall_time_s') if os.path.exists(rr) else None,
                         eval_s=tot([ev.get((c, str(s), sp)) for sp in Q['split']['eval']])))
    for m, c, s in US.jobs(cfg):
        rr = os.path.join(US.run_dir(cfg, m, c, s), 'run_record.json'); eps = [US.eval_path(cfg, m, c, s, sp) for sp in cfg['split']['eval']]
        rows.append(dict(stage='UIU-Net', name=US.u_name(m, c, s), train_s=rjson(rr).get('train_seconds') if os.path.exists(rr) else None,
                         eval_s=tot([M.read_eval(p).get('seconds') if os.path.exists(p) else None for p in eps])))
    return rows


def make(Q, cfg, root, res, out=print):
    evs = list(Q['split']['eval']); N = Q['split']['counts']; masks = list(cfg['u2']['masks']); rule = cfg['u2']['rule']
    Y = yolo_values(Q, root); U = uiunet_values(cfg); T = times(Q, cfg, root, res)
    done = all(v is not None for d in list(Y.values()) + [U[m][c] for m in U for c in U[m]] for v in d.values())
    envp = os.path.join(res, 'logs', 'ENV.json'); envs = rjson(envp) if os.path.exists(envp) else []
    chk = os.path.join(res, 'logs', 'DATA_CHECK.json'); dc = rjson(chk) if os.path.exists(chk) else {}
    col = lambda sp: f'{sp} ({N[sp][0]}장 · Person {N[sp][1]:,})'

    md = ['# IR-compare 보고서 — YOLO11n · UIU-Net × 원영상 · 제안 필터 (HIT-UAV 야간 · 배포 분할)', '', f'> **{HEAD}**', '',
          f'- 만든 때 {now()} · 상태: {"모든 학습 · 평가 끝" if done else "덜 끝남 — 「" + NONE + "」 칸이 있다(같은 명령을 다시 실행하면 이어 간다)"}',
          f'- 데이터: HIT-UAV v1.2.1 야간 · 배포 분할 — 학습 train {N["train"][0]:,}장(Person {N["train"][1]:,}) · 평가 test {N["test"][0]}장 · val {N["val"][0]}장',
          f'- 입력 영상 {dc.get("rows", "?")}행 확인(그중 기준 MANIFEST와 대조한 것 {dc.get("rows_ref", "?")}행 · 기준이 없는 것 {dc.get("rows_noref", "?")}행) · 설정 sha256 `{Q["_sha"]}`',
          '- 지표: Person AP50(점, 0 ~ 100). 모형마다 학습 1회(seed 0) · 마지막 epoch의 가중치로 평가',
          '- 채점: 확신도 순 · 남은 정답 중 IoU 최대 · DontCare IoA ≥ 0.5 미매칭 제외 · [0, r, r끝, 1] 포락선 · 101점. 정답은 HIT-UAV b53106c normal_json이다.', '']

    # ---- 1. 네 모형
    rows = [('YOLO11n', '—', Y['baseline']), ('YOLO11n + 제안 필터', '—', Y['proposed'])]
    for m in masks:
        rows += [('UIU-Net', MASK.get(m, m), U[m]['baseline']), ('UIU-Net + 제안 필터', MASK.get(m, m), U[m]['proposed'])]
    md.extend(['## 1. 네 모형의 Person AP50', '', '| 모형 | 입력 | UIU-Net 정답 마스크 | ' + ' | '.join(col(sp) for sp in evs) + ' |', '|---|---|---|' + '---|' * len(evs)])
    md.extend(f'| {a} | {"[I, P, I]" if "필터" in a else "[I, I, I]"} | {b} | ' + ' | '.join(f2(v[sp]) for sp in evs) + ' |' for a, b, v in rows)
    md.extend(['', f'입력 [I, I, I] = 원영상을 세 채널에 · [I, P, I] = 가운데 채널을 제안 필터 출력으로 바꾼 것. UIU-Net의 출력 상자는 출력 규칙 {rule}(문턱 0.5 · 8-연결 성분의 외접 상자)로 만든다.',
               'YOLO11n의 val은 학습 중에도 쓰였다(epoch마다 검증 — 가중치 선택에는 쓰지 않고 마지막 epoch를 쓴다). UIU-Net은 학습 중에 val을 쓰지 않는다.', ''])

    # ---- 2. 제안 필터 전후
    pair = [('YOLO11n', Y)] + [(f'UIU-Net ({MASK.get(m, m)})', U[m]) for m in masks]
    d_filter = {nm: {sp: sub(v['proposed'][sp], v['baseline'][sp]) for sp in evs} for nm, v in pair}
    md.extend(['## 2. 제안 필터 전후 (제안 필터 − 원영상, 점)', '', '| 모형 | ' + ' | '.join(evs) + ' |', '|---|' + '---|' * len(evs)])
    md.extend(f'| {nm} | ' + ' | '.join(sg(d_filter[nm][sp]) for sp in evs) + ' |' for nm, _ in pair)
    md.append('')

    # ---- 3. UIU-Net − YOLO11n
    d_model = {m: {c: {sp: sub(U[m][c][sp], Y[c][sp]) for sp in evs} for c in ('baseline', 'proposed')} for m in masks}
    md.extend(['## 3. UIU-Net − YOLO11n (같은 입력끼리, 점)', '', '| UIU-Net 정답 마스크 | 입력 | ' + ' | '.join(evs) + ' |', '|---|---|' + '---|' * len(evs)])
    for m in masks:
        md.extend(f'| {MASK.get(m, m)} | {"원영상" if c == "baseline" else "제안 필터"} | ' + ' | '.join(sg(d_model[m][c][sp]) for sp in evs) + ' |' for c in ('baseline', 'proposed'))
    md.append('')

    # ---- 4. 타원 − 상자
    d_mask = None
    if 'ellipse' in U and 'box' in U:
        d_mask = {c: {sp: sub(U['ellipse'][c][sp], U['box'][c][sp]) for sp in evs} for c in ('baseline', 'proposed')}
        md.extend(['## 4. UIU-Net 정답 마스크 방식 (0.5배 타원 − 상자 채움, 점)', '', '| 입력 | ' + ' | '.join(evs) + ' |', '|---|' + '---|' * len(evs)])
        md.extend(f'| {"원영상" if c == "baseline" else "제안 필터"} | ' + ' | '.join(sg(d_mask[c][sp]) for sp in evs) + ' |' for c in ('baseline', 'proposed'))
        md.append('')

    md.extend(['## 5. 실행 환경', ''])
    if envs:
        e = envs[-1]
        md.extend([f'- GPU: {e.get("gpu") or "확인 못 함"}', f'- torch {e.get("torch")} (CUDA {e.get("cuda")}) · ultralytics {e.get("ultralytics")}',
                   f'- python {e.get("python")} · numpy {e.get("numpy")} · opencv {e.get("cv2")} · pillow {e.get("PIL")} · {e.get("os")}'])
        kinds = {(x.get('gpu'), x.get('torch'), x.get('ultralytics')) for x in envs if x.get('stages') != ['report']}
        if len(kinds) > 1:
            md.append(f'- 주의: 실행을 나눠 하는 동안 환경이 {len(kinds)}가지였다(GPU · torch · ultralytics) — results/logs/ENV.json')
    else:
        md.append('- 환경 기록 없음(results/logs/ENV.json)')
    md.append('')

    md.extend(['## 6. 실행마다 걸린 시간', '', '| 모형 | 실행 | 학습 | 평가 (test + val) |', '|---|---|---|---|'])
    md.extend(f'| {r["stage"]} | {r["name"]} | {NONE if r["train_s"] is None else hm(r["train_s"])} | {NONE if r["eval_s"] is None else hm(r["eval_s"])} |' for r in T)
    for st in ('YOLO11n', 'UIU-Net'):
        v = [x for r in T if r['stage'] == st for x in (r['train_s'], r['eval_s'])]
        md.append(f'| {st} 합{"" if all(x is not None for x in v) else " (덜 끝남)"} | | {hm(sum(r["train_s"] or 0 for r in T if r["stage"] == st))} | '
                  f'{hm(sum(r["eval_s"] or 0 for r in T if r["stage"] == st))} |')
    md.extend(['', '끊겼다가 이어 간 UIU-Net 학습의 시간은 epoch 시간의 합이다. 다시 한 YOLO11n 학습은 마지막 한 번의 시간이다.', '',
               '## 읽는 법', '',
               '- 모형마다 학습을 한 번(seed 0)만 했다. 같은 설정이라도 seed가 바뀌면 값이 몇 점씩 달라질 수 있어서, 몇 점 안쪽의 차이로는 어느 쪽이 낫다고 말할 수 없다. 우열을 말하려면 seed를 늘려 다시 재야 한다.',
               '- 배포 분할은 같은 비행(같은 촬영 폴더)의 영상이 train · val · test에 나뉘어 들어 있다. 그래서 학습 때 본 장면과 거의 같은 장면으로 평가하게 되어, 촬영 날짜를 통째로 빼고 평가한 값보다 높게 나온다. 다른 논문의 배포 분할 값과 견줄 때 쓰는 값이다.',
               f'- UIU-Net의 출력 규칙 {rule}은 0.5배 타원 마스크로 학습한 모형에서 고른 것이다. 상자 채움 마스크에는 따로 고르지 않고 같은 규칙을 썼다(출력 상자를 되키우지 않는 것만 다르다).',
               '- 상자 채움 마스크는 상자가 서로 닿은 사람들을 한 덩어리로 만든다. 그러면 출력에서도 한 상자로 나와 여러 사람을 하나로 세게 된다.',
               '- 다른 논문의 값과 견줄 때는 클래스(여기는 Person만) · 야간만인지 · 입력 크기 · 채점 방식이 같은지 먼저 본다.', ''])
    R = dict(at=now(), head=HEAD, complete=done, data_check=dc, cfg_sha256=Q['_sha'], rule=rule, split=Q['split'],
             yolo=Y, uiunet=U, proposed_minus_baseline=d_filter, uiunet_minus_yolo=d_model, ellipse_minus_box=d_mask,
             env=envs[-1] if envs else None, times=T)
    rp = os.path.join(res, 'REPORT.md')
    with open(rp + '.tmp', 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(md))
    os.replace(rp + '.tmp', rp); wjson(os.path.join(res, 'REPORT.json'), R)
    out(f'보고서: {rp}' + ('' if done else ' (덜 끝남)'))
    return R
